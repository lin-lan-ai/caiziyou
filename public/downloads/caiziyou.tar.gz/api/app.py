#!/usr/bin/env python3
"""
菜籽游用户审核API - Python Flask后端
提供用户审核、工具计算等后端功能
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
import mysql.connector
import json
import os
import hashlib
import jwt
import datetime
from functools import wraps
import logging

from account_logger import write_log, read_logs, read_logs_grouped, get_categories as get_log_categories

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, supports_credentials=True)

# 所有 API 响应禁止缓存（防浏览器/proxy缓存动态数据）
@app.after_request
def add_no_cache(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, proxy-revalidate, private'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

# 配置
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'caiziyou-secret-key-2026')
app.config['DATABASE_CONFIG'] = {
    'host': 'localhost',
    'user': 'caiziyou_user',
    'password': 'CaiziYou@2026',
    'database': 'caiziyou_community_db',
    'charset': 'utf8mb4'
}

def get_db_connection():
    """获取数据库连接"""
    try:
        conn = mysql.connector.connect(**app.config['DATABASE_CONFIG'])
        return conn
    except mysql.connector.Error as err:
        logger.error(f"数据库连接失败: {err}")
        return None

def token_required(f):
    """JWT令牌验证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # 从请求头或 query string 获取令牌
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1] if " " in request.headers['Authorization'] else None
        if not token:
            token = request.args.get('token')
        if not token and request.is_json:
            try:
                token = request.json.get('token')
            except: pass
        if not token:
            return jsonify({'error': '令牌缺失'}), 401
        
        try:
            # 解码令牌
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = data['user_id']
            
            # 验证用户是否存在且是管理员
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': '数据库连接失败'}), 500
                
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT id, username, role, status 
                FROM users 
                WHERE id = %s AND role IN ('admin', 'moderator') AND status = 'active'
            """, (current_user_id,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if not user:
                return jsonify({'error': '用户无权限'}), 403
                
        except jwt.ExpiredSignatureError:
            return jsonify({'error': '令牌已过期'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': '无效令牌'}), 401
        except Exception as e:
            logger.error(f"令牌验证错误: {e}")
            return jsonify({'error': '令牌验证失败'}), 401
        
        return f(user, *args, **kwargs)
    
    return decorated

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查"""
    return jsonify({'status': 'ok', 'service': 'caiziyou-api'})

@app.route('/api/login', methods=['POST'])
def login():
    """用户登录"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': '用户名和密码不能为空'}), 400
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, username, password_hash, role, status, registration_status
            FROM users 
            WHERE username = %s
        """, (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if not user:
            return jsonify({'error': '用户不存在'}), 401
        
        # 检查账户状态
        if user['status'] != 'active':
            return jsonify({'error': '账户已被禁用'}), 403
        
        # 检查注册状态
        if user['registration_status'] != 'approved':
            return jsonify({'error': '账户等待管理员审核'}), 403
        
        # 验证密码（这里需要与PHP的密码哈希兼容）
        # 注意：实际使用时需要确保PHP和Python使用相同的哈希算法
        import bcrypt
        
        # 记录操作日志
        write_log(user['id'], 'operation', '登录', f"用户 {user['username']} 登录成功")
        
        if bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
            # 生成JWT令牌
            token = jwt.encode({
                'user_id': user['id'],
                'username': user['username'],
                'role': user['role'],
                'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
            }, app.config['SECRET_KEY'], algorithm='HS256')
            
            return jsonify({
                'success': True,
                'token': token,
                'user': {
                    'id': user['id'],
                    'username': user['username'],
                    'role': user['role']
                }
            })
        else:
            return jsonify({'error': '密码错误'}), 401
            
    except Exception as e:
        logger.error(f"登录错误: {e}")
        return jsonify({'error': '登录失败'}), 500

@app.route('/api/admin/pending-users', methods=['GET'])
@token_required
def get_pending_users(current_user):
    """获取待审核用户列表"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT 
                id, username, email, full_name, user_note, 
                registration_status, created_at
            FROM users 
            WHERE registration_status = 'pending'
            ORDER BY created_at DESC
        """)
        users = cursor.fetchall()
        
        # 获取统计数据
        cursor.execute("SELECT COUNT(*) as total FROM users")
        stats_total = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as active FROM users WHERE status = 'active'")
        stats_active = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as pending FROM users WHERE registration_status = 'pending'")
        stats_pending = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as communities FROM communities WHERE is_public = 1")
        stats_communities = cursor.fetchone()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'count': len(users),
            'users': users,
            'stats': {
                'total_users': stats_total['total'] if stats_total else 0,
                'active_users': stats_active['active'] if stats_active else 0,
                'pending_users': stats_pending['pending'] if stats_pending else 0,
                'communities': stats_communities['communities'] if stats_communities else 0
            }
        })
        
    except Exception as e:
        logger.error(f"获取待审核用户错误: {e}")
        return jsonify({'error': '获取数据失败'}), 500

@app.route('/api/admin/approve-user/<int:user_id>', methods=['POST'])
@token_required
def approve_user(current_user, user_id):
    """审核通过用户"""
    try:
        data = request.get_json()
        review_note = data.get('review_note', '')
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users 
            SET registration_status = 'approved',
                reviewed_by = %s,
                reviewed_at = NOW(),
                review_note = %s,
                status = 'active'
            WHERE id = %s AND registration_status = 'pending'
        """, (current_user['id'], review_note, user_id))
        
        conn.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        conn.close()
        
        if affected_rows > 0:
            logger.info(f"用户 {user_id} 已由 {current_user['username']} 审核通过")
            write_log(current_user['id'], 'operation', '审核用户', f"通过用户 #{user_id} 的注册申请", {'target_user': user_id})
            write_log(user_id, 'operation', '注册审核', '账户已被管理员审核通过')
            return jsonify({'success': True, 'message': '用户审核通过'})
        else:
            return jsonify({'error': '用户不存在或已被审核'}), 404
            
    except Exception as e:
        logger.error(f"审核用户错误: {e}")
        return jsonify({'error': '审核失败'}), 500

@app.route('/api/admin/reject-user/<int:user_id>', methods=['POST'])
@token_required
def reject_user(current_user, user_id):
    """审核拒绝用户"""
    try:
        data = request.get_json()
        review_note = data.get('review_note', '')
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor()
        # 拒绝用户：直接删除（释放用户名和邮箱）
        cursor.execute("""
            DELETE FROM users 
            WHERE id = %s AND registration_status = 'pending'
        """, (user_id,))
        
        conn.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        conn.close()
        
        if affected_rows > 0:
            logger.info(f"用户 {user_id} 已由 {current_user['username']} 审核拒绝")
            write_log(current_user['id'], 'operation', '审核用户', f"拒绝用户 #{user_id} 的注册申请", {'target_user': user_id})
            return jsonify({'success': True, 'message': '用户审核拒绝'})
        else:
            return jsonify({'error': '用户不存在或已被审核'}), 404
            
    except Exception as e:
        logger.error(f"拒绝用户错误: {e}")
        return jsonify({'error': '操作失败'}), 500

@app.route('/api/admin/users', methods=['GET'])
@token_required
def admin_get_users(current_user):
    """获取所有用户列表（管理员用）"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, username, email, full_name, nickname, role, status,
                   registration_status, created_at, last_login
            FROM users
            ORDER BY created_at DESC
        """)
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        
        # 日期格式化
        for u in users:
            if isinstance(u.get('created_at'), datetime.datetime):
                u['created_at'] = u['created_at'].strftime('%Y-%m-%d %H:%M')
            if isinstance(u.get('last_login'), datetime.datetime):
                u['last_login'] = u['last_login'].strftime('%Y-%m-%d %H:%M') if u['last_login'] else None
        
        return jsonify({
            'success': True,
            'count': len(users),
            'users': users
        })
    except Exception as e:
        logger.error(f"获取用户列表错误: {e}")
        return jsonify({'error': '获取数据失败'}), 500


@app.route('/api/admin/delete-user/<int:user_id>', methods=['POST'])
@token_required
def admin_delete_user(current_user, user_id):
    """管理员注销（删除）用户"""
    try:
        if current_user['id'] == user_id:
            return jsonify({'error': '不能删除自己'}), 400
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor()
        cursor.execute("DELETE FROM user_profiles WHERE user_id = %s", (user_id,))
        cursor.execute("DELETE FROM user_sessions WHERE user_id = %s", (user_id,))
        cursor.execute("DELETE FROM community_members WHERE user_id = %s", (user_id,))
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
        
        affected = cursor.rowcount
        cursor.close()
        conn.close()
        
        if affected > 0:
            logger.info(f"用户 {user_id} 已被管理员 {current_user['username']} 删除")
            write_log(current_user['id'], 'operation', '删除用户', f"管理员删除了用户 #{user_id}", {'target_user': user_id})
            return jsonify({'success': True, 'message': '用户已删除'})
        else:
            return jsonify({'error': '用户不存在'}), 404
    except Exception as e:
        logger.error(f"删除用户错误: {e}")
        return jsonify({'error': '删除失败'}), 500


@app.route('/api/tools/json-format', methods=['POST'])
def json_format():
    """JSON格式化工具"""
    try:
        data = request.get_json()
        json_str = data.get('json', '')
        action = data.get('action', 'format')  # format or minify
        
        if not json_str:
            return jsonify({'error': 'JSON内容不能为空'}), 400
        
        import json as json_lib
        parsed = json_lib.loads(json_str)
        
        if action == 'minify':
            result = json_lib.dumps(parsed, separators=(',', ':'))
        else:  # format
            result = json_lib.dumps(parsed, indent=2, ensure_ascii=False)
        
        return jsonify({
            'success': True,
            'result': result,
            'action': action
        })
        
    except json_lib.JSONDecodeError as e:
        return jsonify({'error': f'JSON格式错误: {str(e)}'}), 400
    except Exception as e:
        logger.error(f"JSON工具错误: {e}")
        return jsonify({'error': '处理失败'}), 500

@app.route('/api/tools/base64', methods=['POST'])
def base64_tool():
    """Base64编码/解码工具"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        action = data.get('action', 'encode')  # encode or decode
        
        if not text:
            return jsonify({'error': '文本内容不能为空'}), 400
        
        import base64
        
        if action == 'encode':
            result = base64.b64encode(text.encode('utf-8')).decode('utf-8')
        else:  # decode
            try:
                result = base64.b64decode(text).decode('utf-8')
            except:
                return jsonify({'error': 'Base64解码失败，请检查输入'}), 400
        
        return jsonify({
            'success': True,
            'result': result,
            'action': action
        })
        
    except Exception as e:
        logger.error(f"Base64工具错误: {e}")
        return jsonify({'error': '处理失败'}), 500

@app.route('/api/tools/unit-convert', methods=['POST'])
def unit_convert():
    """单位转换工具"""
    try:
        data = request.get_json()
        value = float(data.get('value', 0))
        from_unit = data.get('from_unit', 'px')
        to_unit = data.get('to_unit', 'rem')
        
        conversions = {
            'px_to_rem': 0.0625,
            'rem_to_px': 16,
            'px_to_em': 0.0625,
            'em_to_px': 16,
            'cm_to_inch': 0.393701,
            'inch_to_cm': 2.54,
            'kb_to_mb': 0.0009765625,
            'mb_to_kb': 1024
        }
        
        # 温度转换（特殊处理）
        if from_unit == 'celsius' and to_unit == 'fahrenheit':
            result = (value * 9/5) + 32
            return jsonify({
                'success': True,
                'result': round(result, 2),
                'from': f"{value} {from_unit}",
                'to': f"{round(result, 2)} {to_unit}"
            })
        if from_unit == 'fahrenheit' and to_unit == 'celsius':
            result = (value - 32) * 5/9
            return jsonify({
                'success': True,
                'result': round(result, 2),
                'from': f"{value} {from_unit}",
                'to': f"{round(result, 2)} {to_unit}"
            })
        
        key = f"{from_unit}_to_{to_unit}"
        if key in conversions:
            result = value * conversions[key]
        else:
            # 尝试反向转换
            reverse_key = f"{to_unit}_to_{from_unit}"
            if reverse_key in conversions:
                result = value / conversions[reverse_key]
            else:
                return jsonify({'error': f'不支持 {from_unit} 到 {to_unit} 的转换'}), 400
        
        return jsonify({
            'success': True,
            'result': round(result, 4),
            'from': f"{value} {from_unit}",
            'to': f"{round(result, 4)} {to_unit}"
        })
        
    except ValueError:
        return jsonify({'error': '请输入有效的数值'}), 400
    except Exception as e:
        logger.error(f"单位转换错误: {e}")
        return jsonify({'error': '转换失败'}), 500

@app.route('/api/tools/color-convert', methods=['POST'])
def color_convert():
    """颜色转换工具"""
    try:
        data = request.get_json()
        color = data.get('color', '#000000')
        format_type = data.get('format', 'hex')  # hex, rgb, hsl
        
        import re
        
        # 验证和解析颜色
        hex_pattern = r'^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$'
        rgb_pattern = r'^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$'
        
        result = {}
        
        if re.match(hex_pattern, color.replace('#', '')):
            # HEX颜色
            hex_color = color.replace('#', '')
            if len(hex_color) == 3:
                hex_color = ''.join([c*2 for c in hex_color])
            
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            
            result['hex'] = f"#{hex_color.upper()}"
            result['rgb'] = f"rgb({r}, {g}, {b})"
            
            # 转换为HSL
            r_norm = r / 255
            g_norm = g / 255
            b_norm = b / 255
            
            cmax = max(r_norm, g_norm, b_norm)
            cmin = min(r_norm, g_norm, b_norm)
            delta = cmax - cmin
            
            if delta == 0:
                h = 0
            elif cmax == r_norm:
                h = 60 * (((g_norm - b_norm) / delta) % 6)
            elif cmax == g_norm:
                h = 60 * (((b_norm - r_norm) / delta) + 2)
            else:
                h = 60 * (((r_norm - g_norm) / delta) + 4)
            
            l = (cmax + cmin) / 2
            s = 0 if delta == 0 else delta / (1 - abs(2 * l - 1))
            
            result['hsl'] = f"hsl({round(h)}, {round(s*100)}%, {round(l*100)}%)"
            
        elif re.match(rgb_pattern, color):
            # RGB颜色
            match = re.match(rgb_pattern, color)
            r, g, b = map(int, match.groups())
            
            # 转换为HEX
            hex_color = f"#{r:02x}{g:02x}{b:02x}".upper()
            result['hex'] = hex_color
            result['rgb'] = color
            
        else:
            return jsonify({'error': '无效的颜色格式'}), 400
        
        return jsonify({
            'success': True,
            'result': result.get(format_type, result['hex']),
            'formats': result
        })
        
    except Exception as e:
        logger.error(f"颜色转换错误: {e}")
        return jsonify({'error': '转换失败'}), 500

# ======== 好友系统 API ========

@app.route('/api/friends/pending-sent', methods=['GET'])
def friends_pending_sent():
    """我发出的待处理好友申请"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'success': True, 'requests': []})
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT fr.id, fr.to_user_id as friend_id, u.username, u.nickname,
                   fr.created_at, fr.status
            FROM friend_requests fr
            JOIN users u ON fr.to_user_id = u.id
            WHERE fr.from_user_id = %s AND fr.status = 'pending'
            ORDER BY fr.created_at DESC
        """, (user_id,))
        requests = cursor.fetchall()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'requests': requests})
    except Exception as e:
        logger.error(f"获取待处理申请错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/friends/search', methods=['GET'])
def friends_search():
    """搜索用户（昵称/用户名/好友码）"""
    try:
        q = request.args.get('q', '').strip()
        user_id = request.args.get('user_id', type=int)
        if not q or not user_id:
            return jsonify({'success': True, 'users': []})
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        pattern = '%' + q + '%'
        cursor.execute("""
            SELECT id, username, nickname, friend_code
            FROM users
            WHERE (username LIKE %s OR nickname LIKE %s OR friend_code LIKE %s)
                AND status = 'active'
            ORDER BY username
            LIMIT 20
        """, (pattern, pattern, pattern))
        users = cursor.fetchall()
        # 标记好友关系和申请状态
        for u in users:
            cursor.execute("""
                SELECT status FROM friend_requests
                WHERE ((from_user_id = %s AND to_user_id = %s)
                    OR (from_user_id = %s AND to_user_id = %s))
                    AND status IN ('accepted', 'pending')
            """, (user_id, u['id'], u['id'], user_id))
            req = cursor.fetchone()
            if req:
                if req['status'] == 'accepted':
                    u['is_friend'] = True
                else:
                    u['has_request'] = True
        cursor.close(); conn.close()
        return jsonify({'success': True, 'users': users})
    except Exception as e:
        logger.error(f"搜索用户错误: {e}")
        return jsonify({'error': '搜索失败'}), 500


@app.route('/api/friends/apply', methods=['POST'])
def friends_apply():
    """发送好友申请（支持 query 搜索用户名/ID）"""
    try:
        data = request.get_json()
        from_id = data.get('user_id') or data.get('from_user_id')
        query = data.get('query', '').strip()
        to_id = data.get('to_user_id')
        # 如果有 query 参数，先搜索用户
        if not to_id and query:
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': '数据库连接失败'}), 500
            cursor = conn.cursor(dictionary=True)
            try:
                # 尝试按 ID 或用户名搜索
                qid = int(query) if query.isdigit() else None
                if qid:
                    cursor.execute("SELECT id FROM users WHERE id = %s", (qid,))
                else:
                    cursor.execute("SELECT id FROM users WHERE username = %s", (query,))
                user = cursor.fetchone()
                if not user:
                    cursor.close(); conn.close()
                    return jsonify({'error': '未找到该用户', 'query': query}), 404
                to_id = user['id']
            except:
                cursor.close(); conn.close()
                return jsonify({'error': '搜索失败'}), 500
            cursor.close(); conn.close()
        if not from_id or not to_id or from_id == to_id:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        # 检查是否已经是好友
        cursor.execute("""
            SELECT id, status FROM friend_requests
            WHERE ((from_user_id = %s AND to_user_id = %s)
                OR (from_user_id = %s AND to_user_id = %s))
                AND status = 'accepted'
        """, (from_id, to_id, to_id, from_id))
        if cursor.fetchone():
            cursor.close(); conn.close()
            return jsonify({'error': '已经是好友了'}), 400
        # 检查对方是否已发送申请
        cursor.execute("""
            SELECT id FROM friend_requests
            WHERE from_user_id = %s AND to_user_id = %s AND status = 'pending'
        """, (to_id, from_id))
        reverse_req = cursor.fetchone()
        if reverse_req:
            cursor.execute("UPDATE friend_requests SET status = 'accepted' WHERE id = %s", (reverse_req['id'],))
            cursor.execute("""INSERT INTO notifications (user_id, type, title, content, related_user_id) SELECT %s, 'friend_accepted', '好友申请通过', CONCAT(username, ' 通过了你的好友申请'), %s FROM users WHERE id = %s""", (to_id, from_id, from_id))
            conn.commit()
            cursor.close(); conn.close()
            write_log(from_id, 'operation', '好友自动同意', f"和用户 #{to_id} 互加好友（自动同意对方已发送的申请）")
            write_log(to_id, 'operation', '好友自动同意', f"和用户 #{from_id} 互加好友（对方自动同意你已发送的申请）")
            return jsonify({'success': True, 'message': '对方已经向你发送过申请，自动同意，你们已经是好友了'}), 200
        # 检查是否已申请

        # 创建申请
        cursor.execute("""
            INSERT INTO friend_requests (from_user_id, to_user_id, status)
            VALUES (%s, %s, 'pending')
        """, (from_id, to_id))
        cursor.execute("""INSERT INTO notifications (user_id, type, title, content, related_user_id) SELECT %s, 'friend_request', '好友申请', CONCAT(username, ' 请求添加你为好友'), %s FROM users WHERE id = %s""", (to_id, from_id, from_id))
        conn.commit()
        cursor.close(); conn.close()
        write_log(from_id, 'operation', '好友申请', f"向用户 #{to_id} 发送了好友申请")
        return jsonify({'success': True, 'message': '好友申请已发送'})
    except Exception as e:
        logger.error(f"好友申请错误: {e}")
        return jsonify({'error': '申请失败'}), 500


@app.route('/api/friends/requests', methods=['GET'])
def friends_requests():
    """获取好友申请列表（收到的+发出的）"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        # 收到的待处理申请
        cursor.execute("""
            SELECT f.id, f.status, f.created_at,
                   u.id as user_id, u.username, u.nickname, u.friend_code
            FROM friend_requests f
            JOIN users u ON f.from_user_id = u.id
            WHERE f.to_user_id = %s
            ORDER BY f.created_at DESC
        """, (user_id,))
        incoming = cursor.fetchall()
        # 发出的申请（包含所有状态）
        cursor.execute("""
            SELECT f.id, f.status, f.created_at,
                   u.id as user_id, u.username, u.nickname, u.friend_code
            FROM friend_requests f
            JOIN users u ON f.to_user_id = u.id
            WHERE f.from_user_id = %s
            ORDER BY f.created_at DESC
        """, (user_id,))
        outgoing = cursor.fetchall()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'incoming': incoming, 'outgoing': outgoing})
    except Exception as e:
        logger.error(f"好友申请列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/friends/handle', methods=['POST'])
def friends_handle():
    """处理好友申请（同意/拒绝）"""
    try:
        data = request.get_json()
        request_id = data.get('request_id')
        action = data.get('action')
        if not request_id or action not in ('accept', 'reject'):
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        new_status = 'accepted' if action == 'accept' else 'rejected'
        cursor.execute("""
            UPDATE friend_requests SET status = %s WHERE id = %s AND status = 'pending'
        """, (new_status, request_id))
        # 给发起方发送通知
        cursor.execute("""
            SELECT fr.from_user_id, fr.to_user_id, u.username
            FROM friend_requests fr
            JOIN users u ON fr.to_user_id = u.id
            WHERE fr.id = %s
        """, (request_id,))
        req_detail = cursor.fetchone()
        if req_detail:
            if action == 'reject':
                cursor.execute("""
                    INSERT INTO notifications (user_id, type, title, content, related_user_id)
                    SELECT %s, 'friend_rejected', '好友申请被拒绝',
                           CONCAT(username, ' 拒绝了你的好友申请'), %s
                    FROM users WHERE id = %s
                """, (req_detail['from_user_id'], req_detail['to_user_id'], req_detail['to_user_id']))
            elif action == 'accept':
                cursor.execute("""
                    INSERT INTO notifications (user_id, type, title, content, related_user_id)
                    SELECT %s, 'friend_accepted', '好友申请通过',
                           CONCAT(username, ' 通过了你的好友申请'), %s
                    FROM users WHERE id = %s
                """, (req_detail['from_user_id'], req_detail['to_user_id'], req_detail['to_user_id']))
        conn.commit()
        cursor.close(); conn.close()
        
        if req_detail:
            act_label = '同意' if action == 'accept' else '拒绝'
            write_log(req_detail['to_user_id'], 'operation', act_label+'好友', f"{act_label}了来自用户 #{req_detail['from_user_id']} 的好友申请")
        
        return jsonify({'success': True, 'message': '操作成功'})
    except Exception as e:
        logger.error(f"处理好友申请错误: {e}")
        return jsonify({'error': '操作失败'}), 500


@app.route('/api/friends/remove', methods=['POST'])
@app.route('/api/friends/delete', methods=['POST'])
def friends_remove():
    """删除好友"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        friend_id = data.get('friend_id')
        logger.info(f"删除好友请求: user_id={user_id}, friend_id={friend_id}, raw_data={data}")
        if not user_id or not friend_id or user_id == friend_id:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        # 删除好友关系（删除双方之间的 accepted 申请）
        cursor.execute("""
            DELETE FROM friend_requests
            WHERE ((from_user_id = %s AND to_user_id = %s)
                OR (from_user_id = %s AND to_user_id = %s))
                AND status = 'accepted'
        """, (user_id, friend_id, friend_id, user_id))
        # 同时删除私聊会话
        if user_id > friend_id:
            user_id, friend_id = friend_id, user_id
        cursor.execute("""
            DELETE FROM private_chats
            WHERE user1_id = %s AND user2_id = %s
        """, (user_id, friend_id))
        conn.commit()
        cursor.close(); conn.close()
        write_log(user_id, 'operation', '删除好友', f"删除了好友 #{friend_id}")
        return jsonify({'success': True, 'message': '已删除好友'})
    except Exception as e:
        logger.error(f"删除好友错误: {e}")
        return jsonify({'error': '删除失败'}), 500



# ======== 用户资料 & 账户日志 API ========

@app.route('/api/user/profile', methods=['GET'])
def user_profile():
    """获取用户资料"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, username, email, nickname, avatar_url, bio, unique_id, role, status,
                   registration_status, created_at
            FROM users WHERE id = %s
        """, (user_id,))
        user = cursor.fetchone()
        cursor.close(); conn.close()
        if not user:
            return jsonify({'error': '用户不存在'}), 404
        return jsonify({'success': True, 'user': user})
    except Exception as e:
        logger.error(f"获取用户资料错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/user/update-profile', methods=['POST'])
def user_update_profile():
    """更新用户资料（昵称/头像）"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        nickname = data.get('nickname', '').strip()
        avatar = data.get('avatar', '').strip()
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        if nickname and nickname.isdigit():
            return jsonify({'error': '昵称不能为纯数字'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        updates = []
        params = []
        if nickname:
            cursor.execute("SELECT id FROM users WHERE nickname = %s AND id != %s", (nickname, user_id))
            if cursor.fetchone():
                cursor.close(); conn.close()
                return jsonify({'error': '昵称已被使用'}), 400
            updates.append("nickname = %s")
            params.append(nickname)
        if avatar:
            updates.append("avatar_url = %s")
            params.append(avatar)
        if not updates:
            cursor.close(); conn.close()
            return jsonify({'success': True, 'message': '无需更新'})
        params.append(user_id)
        cursor.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = %s", params)
        conn.commit(); cursor.close(); conn.close()
        
        write_log(user_id, 'operation', '资料修改', f"更新资料: {', '.join(updates)}")
        return jsonify({'success': True, 'message': '资料已更新'})
    except Exception as e:
        logger.error(f"更新资料错误: {e}")
        return jsonify({'error': '更新失败'}), 500


@app.route('/api/user/change-password', methods=['POST'])
def user_change_password():
    """更改密码"""
    try:
        import bcrypt
        data = request.get_json()
        user_id = data.get('user_id')
        current_pwd = data.get('current_password', '')
        new_pwd = data.get('new_password', '')
        if not user_id or not current_pwd or not new_pwd:
            return jsonify({'error': '参数不完整'}), 400
        if len(new_pwd) < 6:
            return jsonify({'error': '新密码至少6位'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, password_hash, username FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        if not user:
            cursor.close(); conn.close()
            return jsonify({'error': '用户不存在'}), 404
        if not bcrypt.checkpw(current_pwd.encode('utf-8'), user['password_hash'].encode('utf-8')):
            cursor.close(); conn.close()
            return jsonify({'error': '当前密码错误'}), 403
        new_hash = bcrypt.hashpw(new_pwd.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        cursor.execute("UPDATE users SET password_hash = %s WHERE id = %s", (new_hash, user_id))
        conn.commit(); cursor.close(); conn.close()
        
        write_log(user_id, 'operation', '密码更改', '用户更改了登录密码')
        return jsonify({'success': True, 'message': '密码已更改'})
    except Exception as e:
        logger.error(f"更改密码错误: {e}")
        return jsonify({'error': '更改失败'}), 500


@app.route('/api/user/logs', methods=['GET'])
def user_logs():
    """获取用户日志
    Query params:
        user_id:    用户ID（必填）
        category:   分类过滤（可选: recharge/purchase/balance/operation，默认全部）
        limit:      返回条数上限（默认100）
    """
    try:
        user_id = request.args.get('user_id', type=int)
        category = request.args.get('category')
        limit = request.args.get('limit', 100, type=int)
        
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        
        if category and category not in ('recharge', 'purchase', 'balance', 'operation'):
            return jsonify({'error': '无效的分类，可选: recharge/purchase/balance/operation'}), 400
        
        records = read_logs(user_id, category=category, limit=limit)
        categories = get_log_categories()
        
        return jsonify({
            'success': True,
            'count': len(records),
            'logs': records,
            'categories': categories
        })
    except Exception as e:
        logger.error(f"获取用户日志错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/user/logs/stats', methods=['GET'])
def user_logs_stats():
    """获取各分类日志统计"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        
        grouped = read_logs_grouped(user_id, limit_per_category=99999)
        stats = {cat: len(records) for cat, records in grouped.items()}
        
        return jsonify({
            'success': True,
            'stats': stats,
            'categories': get_log_categories()
        })
    except Exception as e:
        logger.error(f"获取日志统计错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/user/notifications/count', methods=['GET'])
def user_notifications_count():
    """获取用户未读角标数（未读消息 + 待处理好友申请）"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        # 未读消息数（别人发给我的未读消息）
        cursor.execute("""
            SELECT COUNT(*) as cnt FROM private_messages pm
            JOIN private_chats pc ON pm.chat_id = pc.id
            WHERE (pc.user1_id = %s OR pc.user2_id = %s)
              AND pm.sender_id != %s AND pm.is_read = FALSE
        """, (user_id, user_id, user_id))
        unread_messages = cursor.fetchone()['cnt']
        # 待处理好友申请（我收到的 pending 请求）
        cursor.execute("""
            SELECT COUNT(*) as cnt FROM friend_requests
            WHERE to_user_id = %s AND status = 'pending'
        """, (user_id,))
        pending_requests = cursor.fetchone()['cnt']
        cursor.close(); conn.close()
        return jsonify({
            'success': True,
            'unread_messages': unread_messages,
            'pending_requests': pending_requests
        })
    except Exception as e:
        logger.error(f"获取未读角标错误: {e}")
        return jsonify({'error': '获取失败'}), 500


# ======== 聊天 API ========

@app.route('/api/chat/create', methods=['POST'])
def chat_create():
    """创建或获取私聊会话"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        target_id = data.get('target_id')
        if not user_id or not target_id or user_id == target_id:
            return jsonify({'error': '参数无效'}), 400
        u1, u2 = (user_id, target_id) if user_id < target_id else (target_id, user_id)
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, user1_id, user2_id FROM private_chats WHERE user1_id = %s AND user2_id = %s", (u1, u2))
        chat = cursor.fetchone()
        if not chat:
            cursor.execute("INSERT INTO private_chats (user1_id, user2_id) VALUES (%s, %s)", (u1, u2))
            conn.commit()
            chat_id = cursor.lastrowid
        else:
            chat_id = chat['id']
        cursor.close(); conn.close()
        write_log(user_id, 'operation', '发起聊天', f"与用户 #{target_id} 开始聊天")
        return jsonify({'success': True, 'chat_id': chat_id})
    except Exception as e:
        logger.error(f"创建会话错误: {e}")
        return jsonify({'error': '创建失败'}), 500


@app.route('/api/chat/send', methods=['POST'])
def chat_send():
    """发送消息"""
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        sender_id = data.get('sender_id')
        content = data.get('content', '').strip()
        msg_type = data.get('message_type', 'text')
        if not chat_id or not sender_id or (not content and msg_type == 'text'):
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        cursor.execute("INSERT INTO private_messages (chat_id, sender_id, message_type, content) VALUES (%s, %s, %s, %s)", (chat_id, sender_id, msg_type, content))
        cursor.execute("UPDATE private_chats SET last_message_at = NOW() WHERE id = %s", (chat_id,))
        conn.commit()
        msg_id = cursor.lastrowid
        cursor.close(); conn.close()
        write_log(sender_id, 'operation', '发送消息', f"在会话 #{chat_id} 中发送了一条消息")
        return jsonify({'success': True, 'message_id': msg_id})
    except Exception as e:
        logger.error(f"发送消息错误: {e}")
        return jsonify({'error': '发送失败'}), 500


@app.route('/api/chat/messages', methods=['GET'])
def chat_messages():
    """获取聊天消息并标记已读"""
    try:
        chat_id = request.args.get('chat_id', type=int)
        user_id = request.args.get('user_id', type=int)
        if not chat_id:
            return jsonify({'error': '缺少参数'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        if user_id:
            cursor.execute("UPDATE private_messages SET is_read = TRUE, read_at = NOW() WHERE chat_id = %s AND sender_id != %s AND is_read = FALSE", (chat_id, user_id))
            conn.commit()
        cursor.execute("SELECT id, chat_id, sender_id, message_type, content, media_url, is_read, created_at FROM private_messages WHERE chat_id = %s ORDER BY created_at ASC LIMIT 100", (chat_id,))
        rows = cursor.fetchall()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'messages': rows, 'count': len(rows)})
    except Exception as e:
        logger.error(f"获取消息错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/chat/conversations', methods=['GET'])
def chat_conversations():
    """获取会话列表（含未读和最后消息）"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT pc.id,
                   CASE WHEN pc.user1_id = %s THEN pc.user2_id ELSE pc.user1_id END AS friend_id,
                   u.username, u.nickname, u.avatar_url, pc.last_message_at,
                   (SELECT content FROM private_messages WHERE chat_id = pc.id ORDER BY created_at DESC LIMIT 1) AS last_message,
                   (SELECT COUNT(*) FROM private_messages WHERE chat_id = pc.id AND sender_id != %s AND is_read = FALSE) AS unread
            FROM private_chats pc
            JOIN users u ON u.id = CASE WHEN pc.user1_id = %s THEN pc.user2_id ELSE pc.user1_id END
            WHERE pc.user1_id = %s OR pc.user2_id = %s
            ORDER BY pc.last_message_at DESC
        """, (user_id, user_id, user_id, user_id, user_id))
        convos = cursor.fetchall()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'conversations': convos})
    except Exception as e:
        logger.error(f"获取会话列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)