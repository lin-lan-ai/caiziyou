/* ===== 菜籽游 App — 纯前端逻辑 ===== */
/* ===== 配置 ===== */


let CURRENT_CHAT_ID = null;
let CHAT_POLL = null;
let ADMIN_TOKEN = sessionStorage.getItem('admin_token') || '';
let JUNIUS_POLL = null;

function byId(id){return document.getElementById(id)}
function qs(s,c){return(c||document).querySelector(s)}
function qsa(s,c){return(c||document).querySelectorAll(s)}
function esc(s){var d=document.createElement('div');d.appendChild(document.createTextNode(String(s)));return d.innerHTML}
function toast(m){
  var t=byId('toast');if(!t){t=document.createElement('div');t.id='toast';t.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1e1e2a;color:#eee;padding:10px 20px;border-radius:8px;z-index:99999;font-size:13px;border:1px solid #2a2a3a;transition:opacity.3s';document.body.appendChild(t)}
  t.textContent=m;t.style.opacity='1';clearTimeout(t._t);t._t=setTimeout(function(){t.style.opacity='0'},2500)
}

/* ===== 面板切换 ===== */
function showPanel(name){
  qsa('.float-panel').forEach(function(p){p.classList.remove('active')});
  var def=byId('panelDefault');if(def)def.style.display='none';
  var p=byId('panel-'+name);if(p)p.classList.add('active');
}
function togglePanel(name){
  var p=byId('panel-'+name);if(!p)return;
  if(p.classList.contains('active')){
    p.classList.remove('active');var def=byId('panelDefault');if(def)def.style.display='';
    qsa('.sidebar-item').forEach(function(s){s.classList.remove('active')});
  }else showPanel(name);
}

/* ===== 侧边栏 ===== */
function initSidebar(){
  if(USER_ROLE!=='admin'){
    qsa('.admin-only').forEach(function(el){el.style.display='none'});
    qsa('.admin-only-mobile').forEach(function(el){el.style.display='none'});
  }
  // 顶部导航 tab 点击（宽屏）
  qsa('.topbar-item').forEach(function(item){
    item.onclick=function(){switchTab(this)};
  });
  // 移动端导航下拉
  var nt=byId('navTrigger'),nd=byId('navDropdown');
  if(nt)nt.onclick=function(e){e.stopPropagation();if(nd)nd.classList.toggle('open')};
  qsa('#navDropdown .dropdown-item').forEach(function(item){
    item.onclick=function(){switchTab(this);if(nd)nd.classList.remove('open')};
  });
  // 头像下拉
  var av=byId('topbarAvatar'),dd=byId('topbarDropdown');
  if(av)av.onclick=function(e){e.stopPropagation();if(dd)dd.classList.toggle('open');if(av)av.classList.toggle('open')};
  function closeAllPopups(e){
    if(nd&&!nd.contains(e.target)&&!nt.contains(e.target)){nd.classList.remove('open')}
    if(dd&&!dd.contains(e.target)&&!av.contains(e.target)){dd.classList.remove('open');av.classList.remove('open')}
  }
  document.addEventListener('click',closeAllPopups);
  // 退出
  var lo=byId('logoutBtn');
  if(lo)lo.onclick=function(){logout()};
  loadFeed();
}
function switchTab(el){
  var tab=el.getAttribute('data-tab');
  qsa('.topbar-item').forEach(function(s){s.classList.remove('active')});
  qsa('#navDropdown .dropdown-item').forEach(function(s){s.classList.remove('active')});
  var match=document.querySelector('.topbar-item[data-tab="'+tab+'"]');
  if(match)match.classList.add('active');
  var dmatch=document.querySelector('#navDropdown .dropdown-item[data-tab="'+tab+'"]');
  if(dmatch)dmatch.classList.add('active');
  showPanel(tab);
  if(tab==='discover')loadFeed();
  if(tab==='service'){renderService();}
  if(tab==='group')renderCommunity();
  if(tab==='chat'){initChat();}
  if(tab==='admin')renderAdmin();
}
function logout(){
  sessionStorage.removeItem('admin_token');
  // 服务端退出：清除 token + session
  fetch('/api/auth/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:USER_ID})}).then(function(){
    window.location.href='/logout.php';
  }).catch(function(){window.location.href='/logout.php'});
}

/* ===== 设置 ===== */
var SETTINGS_LOADED = false;
function renderSettings(){
  var el=byId('settingsContent');if(!el||el.dataset.rendered)return;el.dataset.rendered='1';
  el.innerHTML=
    '<div class="settings-section"><h4 class="settings-section-title"><i class="fas fa-user-circle"></i> 基本资料</h4>'+
    '<div class="settings-card"><div class="settings-row"><span class="settings-label">头像</span><div class="settings-value"><div class="settings-avatar" id="settingsAvatar"><i class="fas fa-user"></i></div><input type="text" class="settings-input" id="settingsAvatarUrl" placeholder="头像URL..." style="flex:1"></div></div>'+
    '<div class="settings-row"><span class="settings-label">昵称</span><input type="text" class="settings-input" id="settingsNickname" placeholder="输入昵称"></div>'+
    '<div class="settings-row"><span class="settings-label">ID</span><span class="settings-value" id="settingsUserId">'+USER_ID+'</span></div>'+
    '<div class="settings-row"><div class="btn btn-sm btn-accent" id="settingsSaveProfile">保存资料</div></div></div></div>'+
    '<div class="settings-section"><h4 class="settings-section-title"><i class="fas fa-key"></i> 账号令牌</h4>'+
    '<div class="settings-card">'+
    '<div class="settings-row"><span class="settings-label">当前密码</span><input type="password" class="settings-input" id="settingsCurPwd" placeholder="输入当前密码"></div>'+
    '<div class="settings-row"><span class="settings-label">新密码</span><input type="password" class="settings-input" id="settingsNewPwd" placeholder="输入新密码"></div>'+
    '<div class="settings-row"><span class="settings-label">确认新密码</span><input type="password" class="settings-input" id="settingsCfmPwd" placeholder="再次输入新密码"></div>'+
    '<div class="settings-row"><div class="btn btn-sm btn-accent" id="settingsChangePwd">更改密码</div></div></div></div>'+
    '<div class="settings-section"><h4 class="settings-section-title"><i class="fas fa-history"></i> 账号日志 <span style="font-size:12px;color:var(--text-dim);font-weight:400">（只读）</span></h4>'+
    '<div class="settings-card"><div id="settingsLogs"><p style="color:var(--text-dim);font-size:13px">加载中...</p></div></div></div>';
  bindSettings();
  loadSettingsProfile();
  loadSettingsLogs();
}
function bindSettings(){
  var sp=byId('settingsSaveProfile');
  if(sp)sp.onclick=function(){saveSettingsProfile()};
  var cp=byId('settingsChangePwd');
  if(cp)cp.onclick=function(){changePassword()};
}
function loadSettingsProfile(){
  fetch('/api/user/profile?user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success)return;
    var u=d.user||d.data||{};
    var ni=byId('settingsNickname');if(ni)ni.value=u.nickname||u.username||'';
    var ai=byId('settingsAvatarUrl');if(ai)ai.value=u.avatar_url||u.avatar||'';
    var id=byId('settingsUserId');if(id)id.textContent='#'+USER_ID+' '+(u.username||'');
  }).catch(function(){});
}
function saveSettingsProfile(){
  var ni=byId('settingsNickname'),ai=byId('settingsAvatarUrl');
  if(!ni)return;
  fetch('/api/user/update-profile',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({user_id:USER_ID,nickname:ni.value,avatar:ai?ai.value:''})
  }).then(function(r){return r.json()}).then(function(d){
    if(d.success)toast('资料已保存');
    else toast('保存失败: '+(d.message||''));
  }).catch(function(){toast('保存失败')});
}
function changePassword(){
  var cur=byId('settingsCurPwd'),nw=byId('settingsNewPwd'),cf=byId('settingsCfmPwd');
  if(!cur||!nw||!cf)return;
  if(nw.value!==cf.value){toast('两次新密码不一致');return}
  if(nw.value.length<6){toast('新密码至少6位');return}
  fetch('/api/user/change-password',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({user_id:USER_ID,current_password:cur.value,new_password:nw.value})
  }).then(function(r){return r.json()}).then(function(d){
    if(d.success){toast('密码已更改');cur.value='';nw.value='';cf.value=''}
    else toast('更改失败: '+(d.message||''));
  }).catch(function(){toast('更改失败')});
}
function loadSettingsLogs(){
  var el=byId('settingsLogs');if(!el)return;
  fetch('/api/user/logs?user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.logs||!d.logs.length){el.innerHTML='<p style="color:var(--text-dim);font-size:13px">暂无日志</p>';return}
    el.innerHTML=d.logs.map(function(l){return'<div class="log-row"><span class="log-date">'+esc(l.created_at||'')+'</span><span class="log-action">'+esc(l.action||l.type||'')+'</span><span class="log-detail">'+esc(l.detail||'')+'</span></div>'}).join('');
  }).catch(function(){el.innerHTML='<p style="color:var(--text-dim);font-size:13px">加载失败</p>'});
}

/* ===== 发现 ===== */
function loadFeed(){
  var el=byId('feedList');if(!el)return;
  fetch('/api/feed/list').then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.feeds||!d.feeds.length){el.innerHTML='<div class="placeholder-box"><i class="fas fa-broadcast-tower"></i><p>暂无动态</p></div>';return}
    el.innerHTML=d.feeds.map(function(f){return'<div class="feed-item"><div class="feed-user">'+esc(f.nickname||f.username)+'</div><div class="feed-content">'+esc(f.content||'')+'</div><div class="feed-time">'+esc(f.created_at||'')+'</div></div>'}).join('');
  }).catch(function(){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>'});
}

/* ===== 服务 ===== */
function renderService(){
  var el=byId('serviceContent');if(!el||el.dataset.rendered)return;el.dataset.rendered='1';
  el.innerHTML=
    '<div class="tool-section"><h4 class="tool-section-title"><i class="fas fa-globe"></i> 公共服务</h4><div class="tool-grid">'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-satellite-dish"></i> VPN节点</h4>'+
    '<div class="svc-info"><span class="svc-label">地址</span><code>154.64.255.112:51820</code></div>'+
    '<div class="svc-info"><span class="svc-label">内网</span><code>10.0.0.2/24</code></div>'+
    '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><a href="/sub/clash.yaml" class="btn btn-sm" target="_blank">Clash</a><a href="/sub/client.conf" class="btn btn-sm" target="_blank">WireGuard</a><a href="/sub/" class="btn btn-sm" target="_blank">教程</a></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-hashtag"></i> JSON</h4><textarea class="tool-ta" id="jsonInput" rows="3" placeholder="输入JSON..."></textarea><div class="tool-buttons"><button class="btn btn-sm" id="formatJsonBtn">格式化</button><button class="btn btn-sm" id="minifyJsonBtn">压缩</button><button class="btn btn-sm" id="validateJsonBtn">验证</button></div><div class="tool-output" id="jsonOutput"></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-lock"></i> Base64</h4><textarea class="tool-ta" id="cryptoInput" rows="3" placeholder="输入文本..."></textarea><div class="tool-buttons"><button class="btn btn-sm" id="encryptBtn">编码</button><button class="btn btn-sm" id="decryptBtn">解码</button></div><div class="tool-output" id="cryptoOutput"></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-ruler"></i> 单位</h4><input class="tool-inp" id="unitValue" placeholder="数值"><div class="form-row" style="margin:4px 0"><select class="tool-sel" id="unitType"><option value="length">长度</option><option value="temp">温度</option></select><select class="tool-sel" id="unitFrom"><option value="m">米</option><option value="cm">厘米</option></select><select class="tool-sel" id="unitTo"><option value="cm">厘米</option><option value="m">米</option></select></div><button class="btn btn-sm" id="convertUnitBtn">换算</button><div class="tool-output" id="unitOutput"></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-palette"></i> 颜色</h4><input type="color" id="colorPicker" value="#007aff" style="height:40px;padding:0;width:100%"><div class="tool-buttons"><button class="btn btn-sm" id="copyHexBtn">HEX</button><button class="btn btn-sm" id="copyRgbBtn">RGB</button><button class="btn btn-sm" id="randomColorBtn">随机</button></div><div class="tool-output" id="colorOutput"></div></div>'+
    '</div></div>'+
    '<div class="tool-section"><h4 class="tool-section-title"><i class="fas fa-laptop"></i> 私有服务</h4><div class="tool-grid">'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-robot"></i> Agent Client</h4><p class="svc-desc">Windows 端客户端，连接纵流私有网络</p><a href="/downloads/agent-client.exe" class="btn btn-accent svc-dl" style=""><i class="fas fa-download"></i> 下载</a></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-cloud-upload-alt"></i> 文件存储</h4><p class="svc-desc">安全可靠的文件托管</p><span class="svc-badge">即将上线</span></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-code"></i> 代码仓库</h4><p class="svc-desc">私有 Git 仓库与协作</p><span class="svc-badge">即将上线</span></div>'+
    '</div></div>'+
    '<div class="tool-section"><h4 class="tool-section-title"><i class="fas fa-users"></i> 团服务</h4><div class="tool-grid">'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-comments"></i> 团聊天</h4><p class="svc-desc">团内即时通讯</p><span class="svc-badge">即将上线</span></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-calendar-alt"></i> 团日程</h4><p class="svc-desc">活动与日程管理</p><span class="svc-badge">即将上线</span></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-share-alt"></i> 团共享</h4><p class="svc-desc">资源协作共享</p><span class="svc-badge">即将上线</span></div>'+
    '</div></div>';
  bindTools();
}
function bindTools(){
  var f=byId('formatJsonBtn');if(f)f.onclick=function(){var i=byId('jsonInput'),o=byId('jsonOutput');if(!i||!o)return;try{o.textContent=JSON.stringify(JSON.parse(i.value),null,2)}catch(e){o.textContent='❌ '+e.message}};
  var m=byId('minifyJsonBtn');if(m)m.onclick=function(){var i=byId('jsonInput'),o=byId('jsonOutput');if(!i||!o)return;try{o.textContent=JSON.stringify(JSON.parse(i.value))}catch(e){o.textContent='❌ '+e.message}};
  var v=byId('validateJsonBtn');if(v)v.onclick=function(){var i=byId('jsonInput'),o=byId('jsonOutput');if(!i||!o)return;try{JSON.parse(i.value);o.textContent='✅ 有效'}catch(e){o.textContent='❌ '+e.message}};
  var enc=byId('encryptBtn');if(enc)enc.onclick=function(){var i=byId('cryptoInput'),o=byId('cryptoOutput');if(!i||!o)return;o.textContent=btoa(i.value)};
  var dec=byId('decryptBtn');if(dec)dec.onclick=function(){var i=byId('cryptoInput'),o=byId('cryptoOutput');if(!i||!o)return;try{o.textContent=atob(i.value)}catch(e){o.textContent='❌ 解码失败'}};
  var conv=byId('convertUnitBtn');if(conv)conv.onclick=function(){
    var v=byId('unitValue'),t=byId('unitType'),f=byId('unitFrom'),to=byId('unitTo'),o=byId('unitOutput');
    if(!v||!o)return;
    fetch('/api/tools/unit-convert',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({value:parseFloat(v.value)||0,fromUnit:f?f.value:'m',toUnit:to?to.value:'cm',type:t?t.value:'length'})}).then(function(r){return r.json()}).then(function(d){if(d.success)o.textContent=d.result||d.value;else o.textContent='❌ '+d.error}).catch(function(){o.textContent='❌ 请求失败'});
  };
  var picker=byId('colorPicker'),co=byId('colorOutput');
  if(picker&&co)picker.oninput=function(){var r=parseInt(picker.value.slice(1,3),16),g=parseInt(picker.value.slice(3,5),16),b=parseInt(picker.value.slice(5,7),16);co.innerHTML='HEX: '+picker.value+'<br>RGB: rgb('+r+','+g+','+b+')'};
  var ch=byId('copyHexBtn');if(ch)ch.onclick=function(){var p=byId('colorPicker');if(!p)return;navigator.clipboard.writeText(p.value).then(function(){toast('已复制')})};
  var cr=byId('copyRgbBtn');if(cr)cr.onclick=function(){var p=byId('colorPicker');if(!p)return;var h=p.value;navigator.clipboard.writeText('rgb('+parseInt(h.slice(1,3),16)+','+parseInt(h.slice(3,5),16)+','+parseInt(h.slice(5,7),16)+')').then(function(){toast('已复制')})};
  var rand=byId('randomColorBtn');if(rand)rand.onclick=function(){var p=byId('colorPicker'),o=byId('colorOutput');if(!p||!o)return;var c='#'+Math.floor(Math.random()*16777215).toString(16).padStart(6,'0');p.value=c;var r=parseInt(c.slice(1,3),16),g=parseInt(c.slice(3,5),16),b=parseInt(c.slice(5,7),16);o.innerHTML='HEX: '+c+'<br>RGB: rgb('+r+','+g+','+b+')'};
}
/* ===== 团 ===== */
function renderCommunity(){
  var el=byId('communityList');if(!el)return;
  fetch('/api/community/list').then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.communities||!d.communities.length){el.innerHTML='<div class="placeholder-box"><i class="fas fa-users"></i><p>暂无团，点击下方创建</p></div>';return}
    el.innerHTML=d.communities.map(function(c){
      return'<div class="community-card card"><div class="card-header"><div class="community-avatar"><i class="fas fa-users"></i></div><div><div class="community-name">'+esc(c.name)+'</div><div class="community-cat">'+esc(c.category||'其他')+'</div></div></div><div class="community-desc">'+esc(c.description||'')+'</div><div class="community-stats"><span><i class="fas fa-user"></i> '+(c.member_count||1)+'</span><span><i class="fas fa-clock"></i> '+esc(c.created_at||'')+'</span></div></div>';
    }).join('');
  }).catch(function(){});
}
function bindGroupTabs(){
  qsa('[data-gtab]').forEach(function(tab){
    tab.onclick=function(){
      qsa('[data-gtab]').forEach(function(t){t.classList.remove('active')});
      tab.classList.add('active');
      renderCommunity();
    };
  });
}

/* ===== 聊天 ===== */
function isWide(){return window.innerWidth>=768}

function initChat(){
  // 重置会话状态
  if(CHAT_POLL){clearInterval(CHAT_POLL);CHAT_POLL=null}
  CURRENT_CHAT_ID=null;
  // 初始布局：窄屏只显示好友列表，宽屏双栏
  var cv=byId('chatConvCol'),ia=byId('chatInputArea');
  if(cv){cv.classList.remove('active');cv.style.display=isWide()?'flex':'none'}
  if(ia)ia.style.display='none';
  var ti=byId('chatConvTitle');
  if(ti)ti.textContent='选择一个好友开始聊天';
  var ms=byId('chatMessages');
  if(ms)ms.innerHTML='<div class="chat-empty">选择一个好友开始聊天</div>';
  // 加载数据
  loadFriendList();
  loadRequests();
  bindFriendSearch();
  // 聊天 tab 切换
  qsa('[data-ctab]').forEach(function(tab){
    tab.onclick=function(){
      qsa('[data-ctab]').forEach(function(t){t.classList.remove('active')});
      tab.classList.add('active');var ct=tab.getAttribute('data-ctab');
      qsa('.chat-list-scroll').forEach(function(s){s.style.display='none'});
      if(ct==='friends'){byId('friendList').style.display='';loadFriendList();}
      if(ct==='requests'){byId('requestList').style.display='';loadRequests();}
    };
  });
  // 返回按钮
  var bb=byId('chatBackBtn');if(bb)bb.onclick=backFromChat;
  // 窗口尺寸变化
  window.addEventListener('resize',onChatResize);
}
function onChatResize(){
  var cv=byId('chatConvCol'),bb=byId('chatBackBtn'),tit=byId('chatConvTitle'),ms=byId('chatMessages'),ia=byId('chatInputArea');if(!cv)return;
  if(isWide()){
    cv.classList.remove('active');
    cv.style.display=CURRENT_CHAT_ID?'flex':'none';
    if(bb)bb.style.display='none';
  } else {
    if(CURRENT_CHAT_ID){
      cv.style.display='flex';
      cv.classList.add('active');
      if(bb)bb.style.display='';
    } else {
      cv.style.display='none';
      cv.classList.remove('active');
      if(bb)bb.style.display='none';
      if(ia)ia.style.display='none';
      if(ms)ms.innerHTML='<div class="chat-empty">选择一个好友开始聊天</div>';
      if(tit)tit.textContent='选择一个好友开始聊天';
    }
  }
}
function backFromChat(){
  // 清除会话，回到好友列表初始状态
  if(CHAT_POLL){clearInterval(CHAT_POLL);CHAT_POLL=null}
  CURRENT_CHAT_ID=null;
  var cv=byId('chatConvCol'),bb=byId('chatBackBtn'),ia=byId('chatInputArea'),ms=byId('chatMessages'),ti=byId('chatConvTitle'),cl=byId('chatListCol'),tb=byId('topbar');
  if(cv){cv.classList.remove('active');cv.style.display=isWide()?'flex':'none'}
  if(cl)cl.style.display='';
  if(tb)tb.style.display='';
  if(bb)bb.style.display='none';
  if(ia)ia.style.display='none';
  if(ms)ms.innerHTML='<div class="chat-empty">选择一个好友开始聊天</div>';
  if(ti)ti.textContent='选择一个好友开始聊天';
  // 好友 tab 设为激活
  qsa('[data-ctab]').forEach(function(t){t.classList.remove('active')});
  var ft=document.querySelector('[data-ctab="friends"]');
  if(ft)ft.classList.add('active');
  qsa('.chat-list-scroll').forEach(function(s){s.style.display='none'});
  var fl=byId('friendList');if(fl)fl.style.display='';
}
function navigateToConv(){
  var cv=byId('chatConvCol'),bb=byId('chatBackBtn'),ia=byId('chatInputArea'),cl=byId('chatListCol'),tb=byId('topbar'),na=byId('navDropdown');
  if(ia)ia.style.display='flex';
  if(!isWide()){
    if(cl)cl.style.display='none';
    if(cv){cv.style.display='flex';cv.classList.add('active')}
    if(bb)bb.style.display='';
    if(tb)tb.style.display='none';
    if(na)na.classList.remove('open');
  }
}

function loadFriendList(searchTerm){
  var el=byId('friendList');if(!el)return;
  fetch('/api/friends/requests?user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success){el.innerHTML='<div class="placeholder-box" style="padding:20px"><p>暂无好友</p></div>';return}
    var list = [];
    if(d.outgoing) list = list.concat(d.outgoing.filter(function(f){return f.status==='accepted'}));
    if(d.incoming) list = list.concat(d.incoming.filter(function(f){return f.status==='accepted'}));
    // 去重（防重复显示同一个人）
    var seen = {};
    list = list.filter(function(u){if(seen[u.user_id])return false;seen[u.user_id]=true;return true});
    if(!list||!list.length){el.innerHTML='<div class="placeholder-box" style="padding:20px"><p>暂无好友</p></div>';return}
    if(searchTerm&&searchTerm.trim()){
      var q=searchTerm.trim().toLowerCase();
      list=list.filter(function(u){return(u.nickname||'').toLowerCase().includes(q)||u.username.toLowerCase().includes(q)});
    }
    el.innerHTML=list.map(function(u){
      var name=esc(u.nickname||u.username);
      var onlineHtml=u.is_online?'<span class="online-dot"></span>':'';
      var badgeHtml=u.unread>0?'<span class="badge">'+u.unread+'</span>':'';
      return'<div class="chat-user-item" data-uid="'+u.user_id+'" data-name="'+name+'"><div class="avatar"><i class="fas fa-user"></i>'+onlineHtml+'</div><div style="flex:1;min-width:0"><div class="friend-name">'+name+'</div><div class="friend-username">@'+esc(u.username)+'</div></div><div style="flex-shrink:0;display:flex;align-items:center;gap:4px">'+badgeHtml+'<button class="btn-unfriend" data-did="'+u.user_id+'" title="删除好友"><i class="fas fa-times"></i></button></div></div>';
    }).join('');
    // 删除好友按钮
    el.querySelectorAll('.btn-unfriend').forEach(function(btn){
      btn.onclick=function(e){e.stopPropagation();var fid=parseInt(this.getAttribute('data-did'));if(!confirm('确定删除好友？'))return;fetch('/api/friends/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:USER_ID,friend_id:fid})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已删除好友');loadFriendList()}else toast(d.error||'删除失败')}).catch(function(){toast('删除失败')})};
    });
    el.querySelectorAll('.chat-user-item').forEach(function(item){
      item.onclick=function(){
        var uid=parseInt(item.getAttribute('data-uid'));
        var name=item.getAttribute('data-name');
        openChat(uid,name);
      };
    });
  }).catch(function(){});
}
function bindFriendSearch(){
  var inp=byId('friendSearch');
  if(!inp)return;
  var _timer;
  inp.oninput=function(){clearTimeout(_timer);_timer=setTimeout(function(){loadFriendList(inp.value)},200)};
}
function loadRequests(){
  var el=byId('requestList');if(!el)return;
  // 添加好友表单（只创建一次）
  var formEl=byId('addFriendForm');
  if(!formEl){
    var f=document.createElement('div');f.id='addFriendForm';
    f.innerHTML='<div style="padding:10px;border-bottom:1px solid rgba(0,0,0,0.04)"><div style="display:flex;gap:8px"><input id="addFriendInput" placeholder="搜索用户名/ID..." style="flex:1;border:1px solid rgba(0,0,0,0.08);border-radius:8px;padding:8px 12px;font-size:13px;outline:none"><button class="btn btn-sm btn-accent" id="addFriendBtn"><i class="fas fa-search"></i> 搜索</button></div><div id="addFriendResult" style="font-size:12px;margin-top:6px"></div></div>';
    el.appendChild(f);
    byId('addFriendBtn').onclick=function(){
      var inp=byId('addFriendInput'),res=byId('addFriendResult');
      if(!inp||!res)return;
      var q=inp.value.trim();
      if(!q){res.textContent='请输入用户名/ID';res.style.color='var(--danger)';return}
      fetch('/api/friends/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:USER_ID,query:q})}).then(function(r){return r.json()}).then(function(d){
        if(d.success){res.innerHTML='<span style="color:#34c759">\u2713 好友申请已发送</span>';inp.value='';loadRequests()}
        else{res.innerHTML='<span style="color:var(--danger)">'+(d.error||d.message||'发送失败')+'</span>'}
      }).catch(function(){res.innerHTML='<span style="color:var(--danger)">网络错误</span>'});
    };
  }
  // 容器
  var listEl=byId('requestListItems');
  if(!listEl){listEl=document.createElement('div');listEl.id='requestListItems';el.appendChild(listEl)}
  // 加载收到的申请 + 已发送的申请
  Promise.all([
    fetch('/api/friends/requests?user_id='+USER_ID).then(function(r){return r.json()}),
    fetch('/api/friends/pending-sent?user_id='+USER_ID).then(function(r){return r.json()})
  ]).then(function(results){
    var incoming=results[0],sent=results[1];
    var html='';
    // ===== 收到的申请 =====
    html+='<div style="padding:8px 12px;font-size:12px;color:var(--text-dim);font-weight:600;border-bottom:1px solid rgba(0,0,0,0.04);display:flex;align-items:center;gap:6px"><i class="fas fa-inbox"></i> 好友申请</div>';
    if(incoming.success&&incoming.incoming){
      var pendingIncoming = incoming.incoming.filter(function(r){return r.status==='pending'});
      if(pendingIncoming.length){
        html+=pendingIncoming.map(function(r){
        return'<div style="padding:10px 12px;border-bottom:1px solid rgba(0,0,0,0.03);display:flex;justify-content:space-between;align-items:center"><span>'+esc(r.username||'用户')+'</span><div><button class="btn btn-sm btn-accent" data-req="'+r.id+'" data-act="accept">同意</button><button class="btn btn-sm btn-danger" data-req="'+r.id+'" data-act="reject" style="margin-left:4px">拒绝</button></div></div>';
      }).join('');
      }else{
        html+='<div style="padding:12px;font-size:13px;color:var(--text-dim);text-align:center;border-bottom:1px solid rgba(0,0,0,0.03)">暂无好友申请</div>';
      }
    }else{
      html+='<div style="padding:12px;font-size:13px;color:var(--text-dim);text-align:center;border-bottom:1px solid rgba(0,0,0,0.03)">暂无好友申请</div>';
    }
    // ===== 我发出的申请 =====
    html+='<div style="padding:8px 12px;font-size:12px;color:var(--text-dim);font-weight:600;border-bottom:1px solid rgba(0,0,0,0.04);display:flex;align-items:center;gap:6px;margin-top:8px"><i class="fas fa-paper-plane"></i> 我发出的申请</div>';
    if(sent.success&&sent.requests&&sent.requests.length){
      html+=sent.requests.map(function(r){
        return'<div style="padding:10px 12px;border-bottom:1px solid rgba(0,0,0,0.03);display:flex;align-items:center;gap:8px"><span>'+esc(r.nickname||r.username)+'</span><span style="font-size:11px;color:var(--accent);background:var(--accent-dim);padding:2px 8px;border-radius:10px">等待通过</span></div>';
      }).join('');
    }else{
      html+='<div style="padding:12px;font-size:13px;color:var(--text-dim);text-align:center">暂无已发送的申请</div>';
    }
    listEl.innerHTML=html;
    listEl.querySelectorAll('[data-req]').forEach(function(btn){
      btn.onclick=function(){
        fetch('/api/friends/handle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:parseInt(this.getAttribute('data-req')),action:this.getAttribute('data-act')})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('操作成功');loadRequests();loadFriendList()}else toast('操作失败')}).catch(function(){});
      };
    });
  }).catch(function(){});
}
function openChat(uid,name){
  if(CHAT_POLL){clearInterval(CHAT_POLL);CHAT_POLL=null}
  CURRENT_CHAT_ID=null;
  var ti=byId('chatConvTitle'),ia=byId('chatInputArea'),ms=byId('chatMessages'),inp=byId('chatInput');
  if(ti)ti.textContent='与 '+name+' 聊天中';
  if(ia)ia.style.display='flex';
  if(inp){inp.value='';setTimeout(function(){inp.focus()},100)}
  if(ia)ia.style.display='';
  if(ms)ms.innerHTML='<div class="chat-empty"><i class="fas fa-spinner fa-spin"></i> 正在建立连接...</div>';
  navigateToConv();
  fetch('/api/chat/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:USER_ID,target_id:uid})}).then(function(r){return r.json()}).then(function(d){
    if(!d.success){if(ms)ms.innerHTML='<div class="chat-empty">创建会话失败</div>';return}
    CURRENT_CHAT_ID=d.chat_id;
    loadMessages();
    CHAT_POLL=setInterval(loadMessages,3000);
  }).catch(function(){if(ms)ms.innerHTML='<div class="chat-empty">请求失败</div>'});
}
function loadMessages(){
  if(!CURRENT_CHAT_ID)return;
  fetch('/api/chat/messages?chat_id='+CURRENT_CHAT_ID+'&user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.messages)return;
    var el=byId('chatMessages');if(!el)return;
    el.innerHTML=d.messages.map(function(m){
      var isMe=parseInt(m.sender_id)===USER_ID;
      return'<div class="chat-msg '+(isMe?'me':'other')+'"><div class="bubble">'+esc(m.content)+'</div><div class="time">'+esc(m.created_at||'')+'</div></div>';
    }).join('');
    el.scrollTop=el.scrollHeight;
  }).catch(function(){});
}
function sendMessage(){
  if(!CURRENT_CHAT_ID)return;
  var inp=byId('chatInput');if(!inp||!inp.value.trim())return;
  var content=inp.value.trim();inp.value='';
  fetch('/api/chat/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:CURRENT_CHAT_ID,sender_id:USER_ID,content:content})}).then(function(r){return r.json()}).then(function(d){
    if(d.success){loadMessages()}else toast('发送失败');
  }).catch(function(){toast('发送失败')});
}
/* ===== 启动时绑定事件 ===== */
function bindEvents(){
byId('sendChatBtn').onclick=sendMessage;
var ci=byId('chatInput');if(ci)ci.onkeydown=function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}};
var cgb=byId('createGroupBtn');if(cgb)cgb.onclick=function(){var m=byId('createGroupModal');if(m)m.classList.add('active')};
var ccg=byId('cancelCreateGroup');if(ccg)ccg.onclick=function(){var m=byId('createGroupModal');if(m)m.classList.remove('active')};
var cgm=byId('createGroupModal');if(cgm)cgm.onclick=function(e){if(e.target===this)this.classList.remove('active')};
byId('submitCreateGroup').onclick=function(){
  var name=byId('createGroupName'),desc=byId('createGroupDesc'),cat=byId('createGroupCategory'),msg=byId('createGroupMsg');
  if(!name||!name.value.trim()){msg.textContent='请输入团名称';return}
  fetch('/api/community/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name.value.trim(),description:desc?desc.value:'',category:cat?cat.value:'其他'})}).then(function(r){return r.json()}).then(function(d){
    if(d.success){toast('创建成功！');byId('createGroupModal').classList.remove('active');name.value='';if(desc)desc.value='';if(msg)msg.textContent='';renderCommunity()}
    else{if(msg)msg.textContent=d.error||'创建失败'}
  }).catch(function(){if(msg)msg.textContent='请求失败'});
};
}

/* ===== 管理面板 ===== */
function renderAdmin(){
  var el=byId('adminContent');if(!el)return;
  if(ADMIN_TOKEN){renderAdminContent();return}
  el.innerHTML=
    '<div class="admin-lock"><i class="fas fa-lock" style="font-size:40px;color:var(--accent-dim)"></i><p style="margin:12px 0;color:var(--text-bright)">管理面板已锁定</p>'+
    '<input id="adminUnlockPwd" type="password" placeholder="输入密码解锁..." style="max-width:280px;margin:0 auto 8px">'+
    '<div id="adminUnlockMsg" style="font-size:12px;color:var(--danger);margin-bottom:8px"></div>'+
    '<button class="btn btn-accent" id="adminUnlockBtn">解锁</button></div>';
  byId('adminUnlockBtn').onclick=function(){
    var pwd=byId('adminUnlockPwd'),msg=byId('adminUnlockMsg');
    if(!pwd||!pwd.value.trim()){if(msg)msg.textContent='请输入密码';return}
    fetch('/api/verify_pwd.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pwd.value.trim()})}).then(function(r){return r.json()}).then(function(d){
      if(d.success&&d.token){ADMIN_TOKEN=d.token;sessionStorage.setItem('admin_token',d.token);renderAdminContent();toast('解锁成功')}
      else{if(msg)msg.textContent=d.error||'密码错误'}
    }).catch(function(){if(msg)msg.textContent='请求失败'});
  };
}
function renderAdminContent(){
  var el=byId('adminContent');if(!el||!ADMIN_TOKEN)return;
  el.innerHTML='<div class="placeholder-box"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';
  // 统计数据
  fetch('/api/admin/pending-users?token='+ADMIN_TOKEN).then(function(r){return r.json()}).then(function(d){
    var pending=d&&d.users?d.users.length:0;
    fetch('/api/admin/users?token='+ADMIN_TOKEN).then(function(r2){return r2.json()}).then(function(d2){
      var total=d2&&d2.users?d2.users.length:0;
      el.innerHTML=
        '<div class="admin-stat-grid"><div class="admin-stat-card" data-asec="users" style="cursor:pointer"><div class="num">'+total+'</div><div class="label">总用户</div></div><div class="admin-stat-card" data-asec="pending" style="cursor:pointer"><div class="num">'+pending+'</div><div class="label">待审核</div></div></div>'+
        '<div id="adminSectionContent"></div>';
      bindAdminTabs();
      loadPendingUsers();
    }).catch(function(){});
  }).catch(function(){});
}
function bindAdminTabs(){
  qsa('[data-asec]').forEach(function(t){
    t.onclick=function(){
      var sec=this.getAttribute('data-asec');
      if(sec==='pending')loadPendingUsers();
      else loadUserList();
    };
  });
  // 默认加载待审核
  loadPendingUsers();
}
function loadPendingUsers(){
  var el=byId('adminSectionContent');if(!el||!ADMIN_TOKEN)return;
  el.innerHTML='<div class="placeholder-box"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';
  fetch('/api/admin/pending-users?token='+ADMIN_TOKEN).then(function(r){return r.json()}).then(function(d){
    if(!d.success){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>';return}
    if(!d.users||!d.users.length){el.innerHTML='<div class="placeholder-box"><i class="fas fa-check-circle" style="color:var(--accent)"></i><p>暂无待审核用户</p></div>';return}
    el.innerHTML=d.users.map(function(u){
      return'<div class="card" style="display:flex;justify-content:space-between;align-items:center"><div><div style="color:var(--text-bright);font-weight:600">'+esc(u.username)+'</div><div style="color:var(--text-dim);font-size:12px">注册: '+esc(u.created_at||'')+'</div></div><div><button class="btn btn-sm btn-accent" data-aprv="'+u.id+'">通过</button><button class="btn btn-sm btn-danger" data-rej="'+u.id+'" style="margin-left:4px">拒绝</button></div></div>';
    }).join('');
    el.querySelectorAll('[data-aprv]').forEach(function(b){
      b.onclick=function(){fetch('/api/admin/approve-user/'+this.getAttribute('data-aprv'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:ADMIN_TOKEN})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已通过');loadPendingUsers()}else toast(d.error||'操作失败')}).catch(function(){})};
    });
    el.querySelectorAll('[data-rej]').forEach(function(b){
      b.onclick=function(){fetch('/api/admin/reject-user/'+this.getAttribute('data-rej'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:ADMIN_TOKEN})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已拒绝');loadPendingUsers()}else toast(d.error)})};
    });
  }).catch(function(){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>'});
}
function loadUserList(){
  var el=byId('adminSectionContent');if(!el||!ADMIN_TOKEN)return;
  fetch('/api/admin/users?token='+ADMIN_TOKEN).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.users){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>';return}
    el.innerHTML=d.users.map(function(u){
      return'<div class="card" style="display:flex;justify-content:space-between;align-items:center"><div><div style="color:var(--text-bright)">'+esc(u.username)+'</div><div style="color:var(--text-dim);font-size:12px">'+esc(u.role||'user')+' · '+(u.status||'')+'</div></div><button class="btn btn-sm btn-danger" data-del="'+u.id+'">删除</button></div>';
    }).join('');
    el.querySelectorAll('[data-del]').forEach(function(b){
      b.onclick=function(){
        if(!confirm('确定删除该用户？'))return;
        fetch('/api/admin/delete-user/'+this.getAttribute('data-del'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:ADMIN_TOKEN})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已删除');loadUserList()}else toast(d.error||'操作失败')}).catch(function(){});
      };
    });
  }).catch(function(){});
}

/* ===== 关闭按钮 ===== */
qsa('[data-close]').forEach(function(btn){
  btn.onclick=function(){togglePanel(this.getAttribute('data-close'))};
});


// ===== 角标轮询 =====
var BADGE_POLL = null;
var KNOWN_BADGES = {};

function updateBadges(count){
  var el = byId("chatBadge");
  if(el){
    if(count>0){el.textContent=count>99?"99+":count;el.style.display="inline-flex"}
    else el.style.display="none";
  }
  var mel = byId("mobileChatBadge");
  if(mel){
    if(count>0){mel.textContent=count>99?"99+":count;mel.style.display="inline-flex"}
    else mel.style.display="none";
  }
}

function pollBadges(){
  fetch("/api/user/notifications/count?user_id="+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success)return;
    var total = (d.unread_messages||0) + (d.pending_requests||0);
    if(total !== KNOWN_BADGES.total){
      var changed = total !== KNOWN_BADGES.total;
      KNOWN_BADGES.total = total;
      updateBadges(total);
      if(changed && KNOWN_BADGES.total !== undefined){
        // 角标变化时同步刷新好友列表和请求（静默，不影响当前视图）
        loadFriendList();
        loadRequests();
      }
    }
  }).catch(function(){});
}

function clearBadge(){
  if(KNOWN_BADGES.total>0){KNOWN_BADGES.total=0;updateBadges(0)}
}

// 覆写 switchTab 加入角标清除
var _origSwitch = switchTab;
switchTab = function(el){
  var tab = el.getAttribute("data-tab");
  if(tab==="chat"||tab==="discover") clearBadge();
  _origSwitch(el);
};


/* ===== 应用启动 ===== */
function startApp(){
  initSidebar();
  bindEvents();
  pollBadges();
  BADGE_POLL = setInterval(pollBadges, 15000);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startApp);
else startApp();
