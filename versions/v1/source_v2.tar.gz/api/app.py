#!/usr/bin/env python3
"""
菜籽游用户审核API - Python Flask后端
提供用户审核、工具计算等后端功能
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
import mysql.connector
import json
import os
import hashlib
import jwt
import datetime
from functools import wraps
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, supports_credentials=True)

# 配置
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'caiziyou-secret-key-2026')
app.config['DATABASE_CONFIG'] = {
    'host': 'localhost',
    'user': 'caiziyou_user',
    'password': 'CaiziYou@2026',
    'database': 'caiziyou_community_db',
    'charset': 'utf8mb4'
}

def get_db_connection():
    """获取数据库连接"""
    try:
        conn = mysql.connector.connect(**app.config['DATABASE_CONFIG'])
        return conn
    except mysql.connector.Error as err:
        logger.error(f"数据库连接失败: {err}")
        return None

def token_required(f):
    """JWT令牌验证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # 从请求头获取令牌
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1] if " " in request.headers['Authorization'] else None
        
        if not token:
            return jsonify({'error': '令牌缺失'}), 401
        
        try:
            # 解码令牌
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = data['user_id']
            
            # 验证用户是否存在且是管理员
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': '数据库连接失败'}), 500
                
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT id, username, role, status 
                FROM users 
                WHERE id = %s AND role IN ('admin', 'moderator') AND status = 'active'
            """, (current_user_id,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if not user:
                return jsonify({'error': '用户无权限'}), 403
                
        except jwt.ExpiredSignatureError:
            return jsonify({'error': '令牌已过期'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': '无效令牌'}), 401
        except Exception as e:
            logger.error(f"令牌验证错误: {e}")
            return jsonify({'error': '令牌验证失败'}), 401
        
        return f(user, *args, **kwargs)
    
    return decorated

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查"""
    return jsonify({'status': 'ok', 'service': 'caiziyou-api'})

@app.route('/api/login', methods=['POST'])
def login():
    """用户登录"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': '用户名和密码不能为空'}), 400
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, username, password_hash, role, status, registration_status
            FROM users 
            WHERE username = %s
        """, (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if not user:
            return jsonify({'error': '用户不存在'}), 401
        
        # 检查账户状态
        if user['status'] != 'active':
            return jsonify({'error': '账户已被禁用'}), 403
        
        # 检查注册状态
        if user['registration_status'] != 'approved':
            return jsonify({'error': '账户等待管理员审核'}), 403
        
        # 验证密码（这里需要与PHP的密码哈希兼容）
        # 注意：实际使用时需要确保PHP和Python使用相同的哈希算法
        import bcrypt
        if bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
            # 生成JWT令牌
            token = jwt.encode({
                'user_id': user['id'],
                'username': user['username'],
                'role': user['role'],
                'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
            }, app.config['SECRET_KEY'], algorithm='HS256')
            
            return jsonify({
                'success': True,
                'token': token,
                'user': {
                    'id': user['id'],
                    'username': user['username'],
                    'role': user['role']
                }
            })
        else:
            return jsonify({'error': '密码错误'}), 401
            
    except Exception as e:
        logger.error(f"登录错误: {e}")
        return jsonify({'error': '登录失败'}), 500

@app.route('/api/admin/pending-users', methods=['GET'])
@token_required
def get_pending_users(current_user):
    """获取待审核用户列表"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT 
                id, username, email, full_name, user_note, 
                registration_status, created_at
            FROM users 
            WHERE registration_status = 'pending'
            ORDER BY created_at DESC
        """)
        users = cursor.fetchall()
        
        # 获取统计数据
        cursor.execute("SELECT COUNT(*) as total FROM users")
        stats_total = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as active FROM users WHERE status = 'active'")
        stats_active = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as pending FROM users WHERE registration_status = 'pending'")
        stats_pending = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as communities FROM communities WHERE is_public = 1")
        stats_communities = cursor.fetchone()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'count': len(users),
            'users': users,
            'stats': {
                'total_users': stats_total['total'] if stats_total else 0,
                'active_users': stats_active['active'] if stats_active else 0,
                'pending_users': stats_pending['pending'] if stats_pending else 0,
                'communities': stats_communities['communities'] if stats_communities else 0
            }
        })
        
    except Exception as e:
        logger.error(f"获取待审核用户错误: {e}")
        return jsonify({'error': '获取数据失败'}), 500

@app.route('/api/admin/approve-user/<int:user_id>', methods=['POST'])
@token_required
def approve_user(current_user, user_id):
    """审核通过用户"""
    try:
        data = request.get_json()
        review_note = data.get('review_note', '')
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users 
            SET registration_status = 'approved',
                reviewed_by = %s,
                reviewed_at = NOW(),
                review_note = %s,
                status = 'active'
            WHERE id = %s AND registration_status = 'pending'
        """, (current_user['id'], review_note, user_id))
        
        conn.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        conn.close()
        
        if affected_rows > 0:
            logger.info(f"用户 {user_id} 已由 {current_user['username']} 审核通过")
            return jsonify({'success': True, 'message': '用户审核通过'})
        else:
            return jsonify({'error': '用户不存在或已被审核'}), 404
            
    except Exception as e:
        logger.error(f"审核用户错误: {e}")
        return jsonify({'error': '审核失败'}), 500

@app.route('/api/admin/reject-user/<int:user_id>', methods=['POST'])
@token_required
def reject_user(current_user, user_id):
    """审核拒绝用户"""
    try:
        data = request.get_json()
        review_note = data.get('review_note', '')
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor()
        # 拒绝用户：直接删除（释放用户名和邮箱）
        cursor.execute("""
            DELETE FROM users 
            WHERE id = %s AND registration_status = 'pending'
        """, (user_id,))
        
        conn.commit()
        affected_rows = cursor.rowcount
        cursor.close()
        conn.close()
        
        if affected_rows > 0:
            logger.info(f"用户 {user_id} 已由 {current_user['username']} 审核拒绝")
            return jsonify({'success': True, 'message': '用户审核拒绝'})
        else:
            return jsonify({'error': '用户不存在或已被审核'}), 404
            
    except Exception as e:
        logger.error(f"拒绝用户错误: {e}")
        return jsonify({'error': '操作失败'}), 500

@app.route('/api/admin/users', methods=['GET'])
@token_required
def admin_get_users(current_user):
    """获取所有用户列表（管理员用）"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, username, email, full_name, nickname, role, status,
                   registration_status, created_at, last_login
            FROM users
            ORDER BY created_at DESC
        """)
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        
        # 日期格式化
        for u in users:
            if isinstance(u.get('created_at'), datetime.datetime):
                u['created_at'] = u['created_at'].strftime('%Y-%m-%d %H:%M')
            if isinstance(u.get('last_login'), datetime.datetime):
                u['last_login'] = u['last_login'].strftime('%Y-%m-%d %H:%M') if u['last_login'] else None
        
        return jsonify({
            'success': True,
            'count': len(users),
            'users': users
        })
    except Exception as e:
        logger.error(f"获取用户列表错误: {e}")
        return jsonify({'error': '获取数据失败'}), 500


@app.route('/api/admin/delete-user/<int:user_id>', methods=['POST'])
@token_required
def admin_delete_user(current_user, user_id):
    """管理员注销（删除）用户"""
    try:
        if current_user['id'] == user_id:
            return jsonify({'error': '不能删除自己'}), 400
        
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        
        cursor = conn.cursor()
        cursor.execute("DELETE FROM user_profiles WHERE user_id = %s", (user_id,))
        cursor.execute("DELETE FROM user_sessions WHERE user_id = %s", (user_id,))
        cursor.execute("DELETE FROM community_members WHERE user_id = %s", (user_id,))
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
        
        affected = cursor.rowcount
        cursor.close()
        conn.close()
        
        if affected > 0:
            logger.info(f"用户 {user_id} 已被管理员 {current_user['username']} 删除")
            return jsonify({'success': True, 'message': '用户已删除'})
        else:
            return jsonify({'error': '用户不存在'}), 404
    except Exception as e:
        logger.error(f"删除用户错误: {e}")
        return jsonify({'error': '删除失败'}), 500


@app.route('/api/tools/json-format', methods=['POST'])
def json_format():
    """JSON格式化工具"""
    try:
        data = request.get_json()
        json_str = data.get('json', '')
        action = data.get('action', 'format')  # format or minify
        
        if not json_str:
            return jsonify({'error': 'JSON内容不能为空'}), 400
        
        import json as json_lib
        parsed = json_lib.loads(json_str)
        
        if action == 'minify':
            result = json_lib.dumps(parsed, separators=(',', ':'))
        else:  # format
            result = json_lib.dumps(parsed, indent=2, ensure_ascii=False)
        
        return jsonify({
            'success': True,
            'result': result,
            'action': action
        })
        
    except json_lib.JSONDecodeError as e:
        return jsonify({'error': f'JSON格式错误: {str(e)}'}), 400
    except Exception as e:
        logger.error(f"JSON工具错误: {e}")
        return jsonify({'error': '处理失败'}), 500

@app.route('/api/tools/base64', methods=['POST'])
def base64_tool():
    """Base64编码/解码工具"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        action = data.get('action', 'encode')  # encode or decode
        
        if not text:
            return jsonify({'error': '文本内容不能为空'}), 400
        
        import base64
        
        if action == 'encode':
            result = base64.b64encode(text.encode('utf-8')).decode('utf-8')
        else:  # decode
            try:
                result = base64.b64decode(text).decode('utf-8')
            except:
                return jsonify({'error': 'Base64解码失败，请检查输入'}), 400
        
        return jsonify({
            'success': True,
            'result': result,
            'action': action
        })
        
    except Exception as e:
        logger.error(f"Base64工具错误: {e}")
        return jsonify({'error': '处理失败'}), 500

@app.route('/api/tools/unit-convert', methods=['POST'])
def unit_convert():
    """单位转换工具"""
    try:
        data = request.get_json()
        value = float(data.get('value', 0))
        from_unit = data.get('from_unit', 'px')
        to_unit = data.get('to_unit', 'rem')
        
        conversions = {
            'px_to_rem': 0.0625,
            'rem_to_px': 16,
            'px_to_em': 0.0625,
            'em_to_px': 16,
            'cm_to_inch': 0.393701,
            'inch_to_cm': 2.54,
            'kb_to_mb': 0.0009765625,
            'mb_to_kb': 1024
        }
        
        # 温度转换（特殊处理）
        if from_unit == 'celsius' and to_unit == 'fahrenheit':
            result = (value * 9/5) + 32
            return jsonify({
                'success': True,
                'result': round(result, 2),
                'from': f"{value} {from_unit}",
                'to': f"{round(result, 2)} {to_unit}"
            })
        if from_unit == 'fahrenheit' and to_unit == 'celsius':
            result = (value - 32) * 5/9
            return jsonify({
                'success': True,
                'result': round(result, 2),
                'from': f"{value} {from_unit}",
                'to': f"{round(result, 2)} {to_unit}"
            })
        
        key = f"{from_unit}_to_{to_unit}"
        if key in conversions:
            result = value * conversions[key]
        else:
            # 尝试反向转换
            reverse_key = f"{to_unit}_to_{from_unit}"
            if reverse_key in conversions:
                result = value / conversions[reverse_key]
            else:
                return jsonify({'error': f'不支持 {from_unit} 到 {to_unit} 的转换'}), 400
        
        return jsonify({
            'success': True,
            'result': round(result, 4),
            'from': f"{value} {from_unit}",
            'to': f"{round(result, 4)} {to_unit}"
        })
        
    except ValueError:
        return jsonify({'error': '请输入有效的数值'}), 400
    except Exception as e:
        logger.error(f"单位转换错误: {e}")
        return jsonify({'error': '转换失败'}), 500

@app.route('/api/tools/color-convert', methods=['POST'])
def color_convert():
    """颜色转换工具"""
    try:
        data = request.get_json()
        color = data.get('color', '#000000')
        format_type = data.get('format', 'hex')  # hex, rgb, hsl
        
        import re
        
        # 验证和解析颜色
        hex_pattern = r'^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$'
        rgb_pattern = r'^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$'
        
        result = {}
        
        if re.match(hex_pattern, color.replace('#', '')):
            # HEX颜色
            hex_color = color.replace('#', '')
            if len(hex_color) == 3:
                hex_color = ''.join([c*2 for c in hex_color])
            
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            
            result['hex'] = f"#{hex_color.upper()}"
            result['rgb'] = f"rgb({r}, {g}, {b})"
            
            # 转换为HSL
            r_norm = r / 255
            g_norm = g / 255
            b_norm = b / 255
            
            cmax = max(r_norm, g_norm, b_norm)
            cmin = min(r_norm, g_norm, b_norm)
            delta = cmax - cmin
            
            if delta == 0:
                h = 0
            elif cmax == r_norm:
                h = 60 * (((g_norm - b_norm) / delta) % 6)
            elif cmax == g_norm:
                h = 60 * (((b_norm - r_norm) / delta) + 2)
            else:
                h = 60 * (((r_norm - g_norm) / delta) + 4)
            
            l = (cmax + cmin) / 2
            s = 0 if delta == 0 else delta / (1 - abs(2 * l - 1))
            
            result['hsl'] = f"hsl({round(h)}, {round(s*100)}%, {round(l*100)}%)"
            
        elif re.match(rgb_pattern, color):
            # RGB颜色
            match = re.match(rgb_pattern, color)
            r, g, b = map(int, match.groups())
            
            # 转换为HEX
            hex_color = f"#{r:02x}{g:02x}{b:02x}".upper()
            result['hex'] = hex_color
            result['rgb'] = color
            
        else:
            return jsonify({'error': '无效的颜色格式'}), 400
        
        return jsonify({
            'success': True,
            'result': result.get(format_type, result['hex']),
            'formats': result
        })
        
    except Exception as e:
        logger.error(f"颜色转换错误: {e}")
        return jsonify({'error': '转换失败'}), 500

# ======== 好友系统 API ========

@app.route('/api/friends/list', methods=['GET'])
def friends_list():
    """获取好友列表（已通过好友申请的用户）"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        # 查找所有通过好友申请的用户
        cursor.execute("""
            SELECT u.id, u.username, u.nickname, u.avatar_url, u.friend_code
            FROM users u
            JOIN friend_requests f ON (
                (f.from_user_id = %s AND f.to_user_id = u.id) OR
                (f.to_user_id = %s AND f.from_user_id = u.id)
            )
            WHERE f.status = 'accepted' AND u.status = 'active'
            ORDER BY u.nickname
        """, (user_id, user_id))
        friends = cursor.fetchall()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'friends': friends})
    except Exception as e:
        logger.error(f"好友列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/friends/search', methods=['GET'])
def friends_search():
    """搜索用户（昵称/用户名/好友码）"""
    try:
        q = request.args.get('q', '').strip()
        user_id = request.args.get('user_id', type=int)
        if not q or not user_id:
            return jsonify({'success': True, 'users': []})
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        pattern = '%' + q + '%'
        cursor.execute("""
            SELECT id, username, nickname, friend_code
            FROM users
            WHERE (username LIKE %s OR nickname LIKE %s OR friend_code LIKE %s)
                AND status = 'active'
            ORDER BY username
            LIMIT 20
        """, (pattern, pattern, pattern))
        users = cursor.fetchall()
        # 标记好友关系和申请状态
        for u in users:
            cursor.execute("""
                SELECT status FROM friend_requests
                WHERE ((from_user_id = %s AND to_user_id = %s)
                    OR (from_user_id = %s AND to_user_id = %s))
                    AND status IN ('accepted', 'pending')
            """, (user_id, u['id'], u['id'], user_id))
            req = cursor.fetchone()
            if req:
                if req['status'] == 'accepted':
                    u['is_friend'] = True
                else:
                    u['has_request'] = True
        cursor.close(); conn.close()
        return jsonify({'success': True, 'users': users})
    except Exception as e:
        logger.error(f"搜索用户错误: {e}")
        return jsonify({'error': '搜索失败'}), 500


@app.route('/api/friends/apply', methods=['POST'])
def friends_apply():
    """发送好友申请"""
    try:
        data = request.get_json()
        from_id = data.get('from_user_id')
        to_id = data.get('to_user_id')
        if not from_id or not to_id or from_id == to_id:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        # 检查是否已经是好友
        cursor.execute("""
            SELECT id, status FROM friend_requests
            WHERE ((from_user_id = %s AND to_user_id = %s)
                OR (from_user_id = %s AND to_user_id = %s))
                AND status = 'accepted'
        """, (from_id, to_id, to_id, from_id))
        if cursor.fetchone():
            cursor.close(); conn.close()
            return jsonify({'error': '已经是好友了'}), 400
        # 检查是否已申请
        cursor.execute("""
            SELECT id FROM friend_requests
            WHERE from_user_id = %s AND to_user_id = %s AND status = 'pending'
        """, (from_id, to_id))
        if cursor.fetchone():
            cursor.close(); conn.close()
            return jsonify({'error': '已发送过申请'}), 400
        # 创建申请
        cursor.execute("""
            INSERT INTO friend_requests (from_user_id, to_user_id, status)
            VALUES (%s, %s, 'pending')
        """, (from_id, to_id))
        conn.commit()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message': '好友申请已发送'})
    except Exception as e:
        logger.error(f"好友申请错误: {e}")
        return jsonify({'error': '申请失败'}), 500


@app.route('/api/friends/requests', methods=['GET'])
def friends_requests():
    """获取好友申请列表（收到的+发出的）"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        # 收到的待处理申请
        cursor.execute("""
            SELECT f.id, f.status, f.created_at,
                   u.id as user_id, u.username, u.nickname, u.friend_code
            FROM friend_requests f
            JOIN users u ON f.from_user_id = u.id
            WHERE f.to_user_id = %s AND f.status = 'pending'
            ORDER BY f.created_at DESC
        """, (user_id,))
        incoming = cursor.fetchall()
        # 发出的申请（包含所有状态）
        cursor.execute("""
            SELECT f.id, f.status, f.created_at,
                   u.id as user_id, u.username, u.nickname, u.friend_code
            FROM friend_requests f
            JOIN users u ON f.to_user_id = u.id
            WHERE f.from_user_id = %s
            ORDER BY f.created_at DESC
        """, (user_id,))
        outgoing = cursor.fetchall()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'incoming': incoming, 'outgoing': outgoing})
    except Exception as e:
        logger.error(f"好友申请列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/friends/handle', methods=['POST'])
def friends_handle():
    """处理好友申请（同意/拒绝）"""
    try:
        data = request.get_json()
        request_id = data.get('request_id')
        action = data.get('action')
        if not request_id or action not in ('accept', 'reject'):
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        new_status = 'accepted' if action == 'accept' else 'rejected'
        cursor.execute("""
            UPDATE friend_requests SET status = %s WHERE id = %s AND status = 'pending'
        """, (new_status, request_id))
        conn.commit()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message': '操作成功'})
    except Exception as e:
        logger.error(f"处理好友申请错误: {e}")
        return jsonify({'error': '操作失败'}), 500


@app.route('/api/friends/remove', methods=['POST'])
def friends_remove():
    """删除好友"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        friend_id = data.get('friend_id')
        if not user_id or not friend_id or user_id == friend_id:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        # 删除好友关系（删除双方之间的 accepted 申请）
        cursor.execute("""
            DELETE FROM friend_requests
            WHERE ((from_user_id = %s AND to_user_id = %s)
                OR (from_user_id = %s AND to_user_id = %s))
                AND status = 'accepted'
        """, (user_id, friend_id, friend_id, user_id))
        # 同时删除私聊会话
        if user_id > friend_id:
            user_id, friend_id = friend_id, user_id
        cursor.execute("""
            DELETE FROM private_chats
            WHERE user1_id = %s AND user2_id = %s
        """, (user_id, friend_id))
        conn.commit()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message': '已删除好友'})
    except Exception as e:
        logger.error(f"删除好友错误: {e}")
        return jsonify({'error': '删除失败'}), 500


# ======== Junius 聊天 API ========

@app.route('/api/junius/send', methods=['POST'])
def junius_send():
    """发送消息给Junius"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        message = data.get('message', '').strip()
        if not user_id or not message:
            return jsonify({'error': '参数无效'}), 400
        if len(message) > 2000:
            return jsonify({'error': '消息太长，请控制在2000字以内'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO junius_chat (user_id, message) VALUES (%s, %s)
        """, (user_id, message))
        conn.commit()
        msg_id = cursor.lastrowid
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message_id': msg_id, 'message': '消息已发送'})
    except Exception as e:
        logger.error(f"Junius发送错误: {e}")
        return jsonify({'error': '发送失败'}), 500


@app.route('/api/junius/history', methods=['GET'])
def junius_history():
    """获取Junius聊天历史"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, message, reply, status, created_at, replied_at
            FROM junius_chat
            WHERE user_id = %s
            ORDER BY created_at ASC
            LIMIT 100
        """, (user_id,))
        messages = cursor.fetchall()
        for m in messages:
            if isinstance(m.get('created_at'), datetime.datetime):
                m['created_at'] = m['created_at'].strftime('%H:%M')
            if isinstance(m.get('replied_at'), datetime.datetime):
                m['replied_at'] = m['replied_at'].strftime('%H:%M')
        cursor.close(); conn.close()
        return jsonify({'success': True, 'messages': messages})
    except Exception as e:
        logger.error(f"Junius历史错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/junius/pending', methods=['GET'])
def junius_pending():
    """获取待回复的消息（给Junius轮询用）"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT jc.id, jc.user_id, jc.message, jc.created_at,
                   u.username, u.nickname
            FROM junius_chat jc
            JOIN users u ON jc.user_id = u.id
            WHERE jc.status = 'pending'
            ORDER BY jc.created_at ASC
            LIMIT 10
        """)
        messages = cursor.fetchall()
        for m in messages:
            if isinstance(m.get('created_at'), datetime.datetime):
                m['created_at'] = m['created_at'].strftime('%Y-%m-%d %H:%M:%S')
        cursor.close(); conn.close()
        return jsonify({'success': True, 'messages': messages})
    except Exception as e:
        logger.error(f"Junius待回复错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/junius/reply', methods=['POST'])
def junius_reply():
    """Junius回复消息"""
    try:
        data = request.get_json()
        msg_id = data.get('message_id')
        reply = data.get('reply', '').strip()
        if not msg_id or not reply:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE junius_chat SET reply = %s, status = 'replied', replied_at = NOW()
            WHERE id = %s AND status = 'pending'
        """, (reply, msg_id))
        conn.commit()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message': '回复成功'})
    except Exception as e:
        logger.error(f"Junius回复错误: {e}")
        return jsonify({'error': '回复失败'}), 500


@app.route('/api/junius/clear', methods=['POST'])
def junius_clear():
    """清空Junius聊天记录"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        cursor.execute("DELETE FROM junius_chat WHERE user_id = %s", (user_id,))
        conn.commit()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message': '已清空'})
    except Exception as e:
        logger.error(f"Junius清空错误: {e}")
        return jsonify({'error': '清空失败'}), 500


@app.route('/api/chat/create', methods=['POST'])
def chat_create():
    """创建或获取私聊会话"""
    try:
        data = request.get_json()
        user1 = data.get('user_id')
        user2 = data.get('target_id')
        if not user1 or not user2 or user1 == user2:
            return jsonify({'error': '参数无效'}), 400
        if user1 > user2:
            user1, user2 = user2, user1
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id FROM private_chats
            WHERE (user1_id = %s AND user2_id = %s)
        """, (user1, user2))
        chat = cursor.fetchone()
        if not chat:
            cursor.execute("""
                INSERT INTO private_chats (user1_id, user2_id) VALUES (%s, %s)
            """, (user1, user2))
            conn.commit()
            chat_id = cursor.lastrowid
        else:
            chat_id = chat['id']
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'chat_id': chat_id})
    except Exception as e:
        logger.error(f"创建会话错误: {e}")
        return jsonify({'error': '创建失败'}), 500


@app.route('/api/chat/send', methods=['POST'])
def chat_send():
    """发送消息"""
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        sender_id = data.get('sender_id')
        content = data.get('content', '')
        if not all([chat_id, sender_id, content]):
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO private_messages (chat_id, sender_id, content)
            VALUES (%s, %s, %s)
        """, (chat_id, sender_id, content))
        conn.commit()
        msg_id = cursor.lastrowid
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'message_id': msg_id})
    except Exception as e:
        logger.error(f"发送消息错误: {e}")
        return jsonify({'error': '发送失败'}), 500


@app.route('/api/chat/messages', methods=['GET'])
def chat_messages():
    """获取聊天消息"""
    chat_id = request.args.get('chat_id')
    if not chat_id:
        return jsonify({'error': '缺少chat_id'}), 400
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT pm.*, u.username, u.nickname, u.avatar_url
            FROM private_messages pm
            JOIN users u ON pm.sender_id = u.id
            WHERE pm.chat_id = %s
            ORDER BY pm.created_at ASC LIMIT 100
        """, (chat_id,))
        msgs = cursor.fetchall()
        cursor.execute("""
            UPDATE private_messages SET is_read = 1
            WHERE chat_id = %s AND is_read = 0
        """, (chat_id,))
        conn.commit()
        for m in msgs:
            if isinstance(m.get('created_at'), datetime.datetime):
                m['created_at'] = m['created_at'].strftime('%H:%M')
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'messages': msgs})
    except Exception as e:
        logger.error(f"获取消息错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/chat/conversations', methods=['GET'])
def chat_conversations():
    """获取用户的所有会话列表"""
    user_id = request.args.get('user_id')
    if not user_id:
        return jsonify({'error': '参数无效'}), 400
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT pc.id as chat_id,
                   (SELECT content FROM private_messages
                    WHERE chat_id = pc.id ORDER BY id DESC LIMIT 1) as last_msg,
                   (SELECT COUNT(*) FROM private_messages
                    WHERE chat_id = pc.id AND sender_id != %s AND is_read = 0) as unread,
                   CASE WHEN pc.user1_id = %s THEN pc.user2_id ELSE pc.user1_id END as other_user_id
            FROM private_chats pc
            WHERE pc.user1_id = %s OR pc.user2_id = %s
            ORDER BY pc.updated_at DESC
        """, (user_id, user_id, user_id, user_id))
        chats = cursor.fetchall()
        for c in chats:
            if c.get('other_user_id'):
                cursor.execute("SELECT id, username, nickname, avatar_url FROM users WHERE id = %s", (c['other_user_id'],))
                u = cursor.fetchone()
                if u:
                    c['other_user'] = u
        cursor.close()
        conn.close()
        total = sum(c['unread'] for c in chats)
        return jsonify({'success': True, 'chats': chats, 'total_unread': total})
    except Exception as e:
        logger.error(f"会话列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/community/create', methods=['POST'])
def community_create():
    """创建团（社群）"""
    try:
        data = request.get_json()
        creator_id = data.get('creator_id')
        name = data.get('name', '').strip()
        description = data.get('description', '').strip()
        category = data.get('category', 'other')
        if not creator_id or not name:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt FROM communities WHERE creator_id = %s AND is_public = 1", (creator_id,))
        cnt = cursor.fetchone()[0]
        if cnt >= 5:
            cursor.close(); conn.close()
            return jsonify({'error': '已达创建上限（5个）'}), 400
        import random
        uid = 'CM' + str(random.randint(100000, 999999))
        cursor.execute("""
            INSERT INTO communities (unique_id, name, description, category, creator_id, member_count, is_public)
            VALUES (%s, %s, %s, %s, %s, 1, 0)
        """, (uid, name, description[:200], category, creator_id,))
        conn.commit()
        community_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO community_members (community_id, user_id, role, join_status) VALUES (%s, %s, 'creator', 'approved')
        """, (community_id, creator_id))
        conn.commit()
        cursor.close(); conn.close()
        logger.info(f"团创建成功: {name} (ID:{community_id})")
        return jsonify({'success': True, 'community_id': community_id, 'message': '申请已提交，等待审核'})
    except Exception as e:
        logger.error(f"创建团错误: {e}")
        return jsonify({'error': '创建失败'}), 500


@app.route('/api/community/list', methods=['GET'])
def community_list():
    """获取社群列表（团广场）"""
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT c.*, u.username as creator_name, u.nickname as creator_nickname
            FROM communities c JOIN users u ON c.creator_id = u.id
            WHERE c.is_public = 1 ORDER BY c.member_count DESC, c.created_at DESC
        """)
        communities = cursor.fetchall()
        for c in communities:
            if isinstance(c.get('created_at'), datetime.datetime):
                c['created_at'] = c['created_at'].strftime('%Y-%m-%d')
        cursor.close(); conn.close()
        return jsonify({'success': True, 'communities': communities})
    except Exception as e:
        logger.error(f"社群列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


@app.route('/api/community/my', methods=['GET'])
def community_my():
    """获取我加入的团列表（团聚合）"""
    try:
        user_id = request.args.get('user_id', type=int)
        if not user_id:
            return jsonify({'error': '缺少用户ID'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT c.*, cm.role, cm.joined_at
            FROM communities c
            JOIN community_members cm ON c.id = cm.community_id
            WHERE cm.user_id = %s AND cm.join_status = 'approved'
            ORDER BY cm.joined_at DESC
        """, (user_id,))
        communities = cursor.fetchall()
        for c in communities:
            if isinstance(c.get('created_at'), datetime.datetime):
                c['created_at'] = c['created_at'].strftime('%Y-%m-%d')
            if isinstance(c.get('joined_at'), datetime.datetime):
                c['joined_at'] = c['joined_at'].strftime('%Y-%m-%d')
        cursor.close(); conn.close()
        return jsonify({'success': True, 'communities': communities})
    except Exception as e:
        logger.error(f"获取我的团列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


# ======== 用户设置 API ========

@app.route('/api/user/update-profile', methods=['POST'])
def update_profile():
    """更新用户资料"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        nickname = data.get('nickname', '').strip()
        bio = data.get('bio', '').strip()
        if not user_id:
            return jsonify({'error': '参数无效'}), 400
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor()
        if nickname:
            cursor.execute("UPDATE users SET nickname = %s WHERE id = %s", (nickname[:50], user_id))
        cursor.execute("UPDATE users SET bio = %s WHERE id = %s", (bio[:500] if bio else '', user_id))
        conn.commit()
        cursor.close(); conn.close()
        return jsonify({'success': True, 'message': '保存成功'})
    except Exception as e:
        logger.error(f"更新资料错误: {e}")
        return jsonify({'error': '保存失败'}), 500


# ======== 推流（动态）API ========

@app.route('/api/feed/list', methods=['GET'])
def feed_list():
    """获取推流动列表"""
    import random
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': '数据库连接失败'}), 500
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT ua.*, u.username, u.nickname, u.avatar_url
            FROM user_activities ua JOIN users u ON ua.user_id = u.id
            ORDER BY ua.created_at DESC LIMIT 20
        """)
        feeds = cursor.fetchall()
        for f in feeds:
            if isinstance(f.get('created_at'), datetime.datetime):
                f['created_at'] = f['created_at'].strftime('%m-%d %H:%M')
            f['likes'] = random.randint(0, 30)
            f['comments'] = random.randint(0, 10)
        cursor.close(); conn.close()
        return jsonify({'success': True, 'feeds': feeds})
    except Exception as e:
        logger.error(f"推流列表错误: {e}")
        return jsonify({'error': '获取失败'}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)