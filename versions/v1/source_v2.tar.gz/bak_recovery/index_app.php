<?php
/**
 * 菜籽游x纵流社群 - 极客风格主页
 */
require_once __DIR__ . '/../includes/community_config.php';

// 如果用户未登录，重定向到登录页面
if (!isCommunityLoggedIn()) {
    communityRedirect('login.php');
}

$currentUser = getCurrentCommunityUser();
$userId = getCurrentCommunityUserId();

// 获取当前选项卡
$currentTab = $_GET['tab'] ?? 'discover';

// 获取系统设置
$siteName = getSystemSetting('site_name', '菜籽游x纵流社群');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5, user-scalable=yes">
    <title>菜籽游 · 极客社交</title>
    
    <!-- CSS -->
    <link rel="stylesheet" href="/assets/css/geek.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- JavaScript -->
    <script src="/debug_log.js"></script>
    <script src="/api_tools.js"></script>
    <script src="/admin_approve.js"></script>
    
    <!-- 可见调试面板 -->
    <script>
    // 在所有JS执行完后创建可见调试区
    document.addEventListener('DOMContentLoaded', function() {
        var dbg = document.createElement('div');
        dbg.id = 'debug-toast';
        dbg.style.cssText = 'position:fixed;bottom:60px;right:10px;z-index:9999;background:rgba(0,0,0,0.9);color:#0f0;font-size:12px;padding:10px;border-radius:6px;max-width:400px;max-height:200px;overflow:auto;font-family:monospace;';
        document.body.appendChild(dbg);
        
        function toast(msg) {
            dbg.innerHTML = '<div>' + new Date().toLocaleTimeString() + ' ' + msg + '</div>' + dbg.innerHTML;
            if (dbg.children.length > 10) dbg.removeChild(dbg.lastChild);
        }
        window.__toast = toast;
        
        toast('调试面板已加载');
        
        // 检查关键对象
        toast('API工具箱: ' + (typeof window.initToolboxExternal === 'function' ? '✅' : '❌'));
        toast('管理面板: ' + (typeof window.initAdminPanelExternal === 'function' ? '✅' : '❌'));
        
        // 检查按钮是否存在
        setTimeout(function() {
            toast('formatJsonBtn: ' + (document.getElementById('formatJsonBtn') ? '✅' : '❌'));
            toast('jsonInput: ' + (document.getElementById('jsonInput') ? '✅' : '❌'));
        }, 500);
    });
    </script>
    
    <!-- 强制错误处理 -->
    <script>
    // 强制启用调试
    if (typeof DEBUG !== 'undefined' && DEBUG) {
        try {
            DEBUG.enabled = true;
            DEBUG.level = 'debug';
            DEBUG.info('🔧 强制调试模式已启用');
            DEBUG.info('🔧 调试系统就绪，等待应用初始化');
        } catch(e) {}
    }
    </script>
    
    <style>
        /* 页面特定样式 */
        body {
            background: #1e1e24;
            overflow: auto;
        }
        .app-layout {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }
        
        /* Canvas背景 */
        #bgCanvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }
        
        /* 工具箱特定样式 */
        .tool-section {
            margin-bottom: var(--spacing-2xl);
        }
        
        .tool-section-title {
            color: var(--accent);
            font-size: 1.25rem;
            margin-bottom: var(--spacing-lg);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
            border-bottom: 1px solid var(--accent);
            padding-bottom: var(--spacing-sm);
        }
        
        .tool-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: var(--spacing-lg);
        }
        
        /* 团广场样式 */
        .community-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: var(--spacing-lg);
            margin-top: var(--spacing-lg);
        }
        
        .community-card {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--green);
            border-radius: var(--radius-none);
            padding: var(--spacing-lg);
            transition: all var(--transition-fast);
            position: relative;
            overflow: hidden;
        }
        
        .community-card:hover {
            border-color: var(--accent);
            box-shadow: 0 0 20px rgba(69, 243, 255, 0.3);
            transform: translateY(-5px);
        }
        
        .community-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--pink), var(--accent));
        }
        
        .community-header {
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-md);
        }
        
        .community-avatar {
            width: 50px;
            height: 50px;
            border-radius: var(--radius-none);
            border: 2px solid var(--green);
            overflow: hidden;
            flex-shrink: 0;
        }
        
        .community-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .community-info {
            flex: 1;
        }
        
        .community-name {
            color: var(--green);
            font-size: 1.125rem;
            font-weight: 600;
            margin-bottom: var(--spacing-xs);
        }
        
        .community-category {
            color: var(--text-secondary);
            font-size: 0.8em;
            background: rgba(46, 204, 113, 0.1);
            padding: 2px 8px;
            border-radius: var(--radius-none);
            display: inline-block;
        }
        
        .community-description {
            color: var(--text-secondary);
            font-size: 0.9em;
            line-height: 1.4;
            margin-bottom: var(--spacing-md);
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .community-stats {
            display: flex;
            justify-content: space-between;
            color: var(--text-secondary);
            font-size: 0.8em;
            margin-bottom: var(--spacing-md);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
        }
        
        .community-actions {
            display: flex;
            gap: var(--spacing-sm);
        }
        
        /* 发现页面样式 */
        .discover-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: var(--spacing-lg);
            margin-top: var(--spacing-lg);
        }
        
        .discover-card {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--purple);
            border-radius: var(--radius-none);
            padding: var(--spacing-lg);
            transition: all var(--transition-fast);
            text-align: center;
        }
        
        .discover-card:hover {
            border-color: var(--accent);
            box-shadow: 0 0 20px rgba(69, 243, 255, 0.3);
            transform: translateY(-5px);
        }
        
        .discover-icon {
            font-size: 2.5rem;
            color: var(--purple);
            margin-bottom: var(--spacing-md);
        }
        
        .discover-title {
            color: var(--text-primary);
            font-size: 1.125rem;
            margin-bottom: var(--spacing-sm);
        }
        
        .discover-description {
            color: var(--text-secondary);
            font-size: 0.9em;
            line-height: 1.4;
        }
        
        /* 团子标签样式 */
        .group-square-controls {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        .group-subtabs {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            border-bottom: 1px solid rgba(69,243,255,0.2);
            padding-bottom: 10px;
        }
        
        .subtab-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            color: var(--text-secondary);
            cursor: pointer;
            border-radius: 6px;
            transition: all 0.25s ease;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .subtab-item:hover {
            background: rgba(69,243,255,0.08);
            color: var(--text-primary);
        }
        
        .subtab-item.active {
            background: rgba(69,243,255,0.15);
            color: var(--accent);
            border: 1px solid rgba(69,243,255,0.3);
        }
        
        .subtab-item i {
            font-size: 1rem;
        }
        
        .subtab-title {
            color: var(--green);
            font-size: 1.1rem;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .group-subcontent {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        
        .group-subcontent.active {
            display: block;
        }
        
        /* 推流样式（类似抖音） */
        .feed-container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .feed-item {
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(69,243,255,0.15);
            border-radius: 12px;
            margin-bottom: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .feed-item:hover {
            border-color: rgba(69,243,255,0.3);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        }
        
        .feed-header {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid rgba(69,243,255,0.1);
        }
        
        .feed-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid var(--green);
            margin-right: 12px;
            overflow: hidden;
        }
        
        .feed-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .feed-user {
            flex: 1;
        }
        
        .feed-username {
            color: var(--text-primary);
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        .feed-time {
            color: var(--text-secondary);
            font-size: 0.8rem;
            margin-top: 2px;
        }
        
        .feed-content {
            padding: 15px;
        }
        
        .feed-text {
            color: var(--text-primary);
            line-height: 1.5;
            margin-bottom: 15px;
        }
        
        .feed-media {
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 15px;
            background: rgba(0,0,0,0.5);
            min-height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
        }
        
        .feed-actions {
            display: flex;
            gap: 20px;
            padding: 10px 15px;
            border-top: 1px solid rgba(69,243,255,0.1);
        }
        
        .feed-action {
            display: flex;
            align-items: center;
            gap: 6px;
            color: var(--text-secondary);
            cursor: pointer;
            transition: color 0.2s;
        }
        
        .feed-action:hover {
            color: var(--accent);
        }
        
        .feed-action.liked {
            color: var(--pink);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        /* 服务页面样式 */
        .service-list {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-md);
            margin-top: var(--spacing-lg);
        }
        
        .service-item {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--yellow);
            border-radius: var(--radius-none);
            padding: var(--spacing-lg);
            transition: all var(--transition-fast);
            display: flex;
            align-items: center;
            gap: var(--spacing-lg);
        }
        
        .service-item:hover {
            border-color: var(--accent);
            box-shadow: 0 0 20px rgba(69, 243, 255, 0.3);
            transform: translateX(5px);
        }
        
        .service-icon {
            font-size: 2rem;
            color: var(--yellow);
            flex-shrink: 0;
        }
        
        .service-content {
            flex: 1;
        }
        
        .service-title {
            color: var(--text-primary);
            font-size: 1.125rem;
            margin-bottom: var(--spacing-sm);
        }
        
        .service-description {
            color: var(--text-secondary);
            font-size: 0.9em;
            line-height: 1.4;
        }
        
        /* 管理员面板样式 */
        .admin-panel {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--pink);
            border-radius: var(--radius-none);
            padding: var(--spacing-lg);
            margin-top: var(--spacing-lg);
        }
        
        .admin-section {
            margin-bottom: var(--spacing-xl);
        }
        
        .admin-section-title {
            color: var(--pink);
            font-size: 1.25rem;
            margin-bottom: var(--spacing-md);
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
        }
        
        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-xl);
        }
        
        .stat-card {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid var(--green);
            border-radius: var(--radius-none);
            padding: var(--spacing-md);
            text-align: center;
        }
        
        .stat-value {
            color: var(--accent);
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: var(--spacing-xs);
        }
        
        .stat-label {
            color: var(--text-secondary);
            font-size: 0.9em;
        }
        
        /* 响应式设计 */
        @media (max-width: 768px) {
            .tool-grid,
            .community-grid,
            .discover-grid {
                grid-template-columns: 1fr;
            }
            
            .admin-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .service-item {
                flex-direction: column;
                text-align: center;
                gap: var(--spacing-md);
            }
            
            .sidebar {
                width: 80px;
            }
            
            .sidebar-item span {
                font-size: 0.7em;
            }
        }
        
        @media (max-width: 480px) {
            .admin-stats {
                grid-template-columns: 1fr;
            }
            
            .community-actions {
                flex-direction: column;
            }
            
            .sidebar {
                width: 60px;
            }
            
            .sidebar-item {
                padding: var(--spacing-md) var(--spacing-xs);
            }
            
            .sidebar-item i {
                font-size: 1.2rem;
            }
            
            .sidebar-item span {
                display: none;
            }
        }
        
        /* 打印样式 */
        @media print {
            .sidebar,
            .top-bar,
            .bottom-bar {
                display: none !important;
            }
            
            .content-area {
                margin: 0 !important;
                padding: 0 !important;
                background: #fff !important;
                color: #000 !important;
            }
            
            .tab-content {
                display: block !important;
            }
            
            .community-card,
            .discover-card,
            .service-item {
                border: 1px solid #000 !important;
                background: #fff !important;
                color: #000 !important;
                break-inside: avoid;
            }
        }
        
        /* 内联聊天样式 */
        .chat-body-inline {
            display: flex;
            height: calc(100vh - 180px);
            gap: 12px;
        }
        .chat-sidebar-inline {
            width: 200px;
            flex-shrink: 0;
            border-right: 1px solid rgba(69,243,255,0.1);
            overflow-y: auto;
        }
        .chat-tabs {
            display: flex;
            gap: 4px;
            margin-bottom: 10px;
        }
        .chat-tab {
            flex: 1;
            padding: 8px 4px;
            background: transparent;
            border: 1px solid rgba(69,243,255,0.15);
            border-radius: 6px;
            color: var(--text-secondary);
            font-size: 13px;
            cursor: pointer;
            text-align: center;
        }
        .chat-tab.active {
            background: rgba(69,243,255,0.15);
            color: var(--accent);
            border-color: rgba(69,243,255,0.3);
        }
        .chat-area-inline {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .chat-conversation {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }
        .chat-input-area {
            display: flex;
            gap: 8px;
            padding: 10px 0;
            border-top: 1px solid rgba(69,243,255,0.1);
        }
        .chat-input-area textarea {
            flex: 1;
            padding: 10px;
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(69,243,255,0.15);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 14px;
            resize: none;
            outline: none;
        }
        .chat-input-area button {
            padding: 10px 20px;
            background: var(--accent);
            border: none;
            border-radius: 8px;
            color: #fff;
            cursor: pointer;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Canvas背景 -->
    <canvas id="bgCanvas"></canvas>
    
    <div id="app">
        <!-- 主页 -->
        <div id="home-page" class="page active">
            <!-- 统一顶部栏 -->
            <?php include __DIR__ . '/../includes/topbar.php'; ?>
            
            <!-- 主内容区 -->
            <div class="main-content">
                <!-- 侧边栏 -->
                <div class="sidebar">
                    <div class="sidebar-item <?php echo $currentTab === 'discover' ? 'active' : ''; ?>" data-tab="discover">
                        <i class="fas fa-compass"></i>
                        <span>发现</span>
                    </div>
                    
                    <div class="sidebar-item <?php echo $currentTab === 'service' ? 'active' : ''; ?>" data-tab="service">
                        <i class="fas fa-concierge-bell"></i>
                        <span>服务</span>
                    </div>
                    
                    <div class="sidebar-item <?php echo $currentTab === 'group' ? 'active' : ''; ?>" data-tab="group">
                        <i class="fas fa-users"></i>
                        <span>团</span>
                    </div>
                    
                    <div class="sidebar-item" data-tab="chat" id="sidebarChatBtn">
                        <i class="fas fa-comment-dots"></i>
                        <span>消息</span>
                    </div>
                    
                    <?php if (isset($currentUser['role']) && $currentUser['role'] === 'admin'): ?>
                    <div class="sidebar-item <?php echo $currentTab === 'admin' ? 'active' : ''; ?>" data-tab="admin">
                        <i class="fas fa-shield-alt"></i>
                        <span>管理</span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- 内容区域 -->
                <div class="content-area">
                    <!-- 团广场 -->
                    <div class="tab-content <?php echo $currentTab === 'group' ? 'active' : ''; ?>" id="tab-group">
                        <h3 class="tab-title">
                            <i class="fas fa-users"></i>
                            团 · 聚合
                        </h3>
                        
                        <!-- 团内子标签导航 -->
                        <div class="group-subtabs">
                            <div class="subtab-item active" data-subtab="square">
                                <i class="fas fa-th-large"></i>
                                <span>团广场</span>
                            </div>
                        </div>
                        
                        <!-- 团广场 - 展示社群（团推流已移至发现页面） -->
                        <div class="group-subcontent active" id="group-square">
                        <div class="group-subcontent" id="group-square">
                            <h4 class="subtab-title"><i class="fas fa-th-large"></i> 团广场 · 发现社群</h4>
                            <div class="group-square-controls">
                                <button class="btn btn-primary" id="createGroupBtn" style="padding:10px 20px;background:var(--accent);color:#fff;border:none;border-radius:var(--radius-md);cursor:pointer;font-size:14px;font-weight:bold;">
                                    <i class="fas fa-plus"></i> 创建团
                                </button>
                                <div style="position:relative;flex:1;max-width:300px;">
                                    <input type="text" id="searchGroupInput" placeholder="搜索团..." 
                                           style="width:100%;padding:10px 14px;background:#0a0a0f;border:1px solid #333;border-radius:4px;color:#fff;font-size:14px;outline:none;box-sizing:border-box;">
                                    <i class="fas fa-search" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#666;"></i>
                                </div>
                            </div>
                            <div class="community-grid" id="communityList">
                                <div class="placeholder-box">
                                    <i class="fas fa-users"></i>
                                    <p>社群广场功能正在开发中，敬请期待...</p>
                                    <span class="placeholder-label">即将上线</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 服务 -->
                    <div class="tab-content <?php echo $currentTab === 'service' ? 'active' : ''; ?>" id="tab-service">
                        <h3 class="tab-title">
                            <i class="fas fa-concierge-bell"></i>
                            公共服务
                        </h3>
                        
                        <!-- 节点 -->
                        <div class="tool-section">
                            <h4 class="tool-section-title">
                                <i class="fas fa-satellite-dish"></i>
                                VPN节点
                            </h4>
                            <div id="proxyNodesList">
                                <div style="text-align:center;padding:30px;color:#888;"><i class="fas fa-spinner fa-spin"></i> 加载中...</div>
                            </div>
                        </div>
                        
                        <!-- 工具箱 -->
                        <div class="tool-section">
                            <h4 class="tool-section-title">
                                <i class="fas fa-tools"></i>
                                在线工具箱
                            </h4>
                            <div class="tool-grid">
                                <div class="tool-card">
                                    <h4 class="tool-card-title">
                                        <i class="fas fa-hashtag"></i>
                                        JSON格式化
                                    </h4>
                                    <textarea class="tool-input" id="jsonInput" placeholder="输入JSON字符串..." rows="4">{"name": "菜籽游", "version": "1.0.0", "features": ["社群", "私聊", "工具箱"]}</textarea>
                                    <div class="tool-buttons">
                                        <button class="tool-btn" id="formatJsonBtn">格式化</button>
                                        <button class="tool-btn" id="minifyJsonBtn">压缩</button>
                                        <button class="tool-btn" id="validateJsonBtn">验证</button>
                                    </div>
                                    <div class="tool-output" id="jsonOutput"></div>
                                </div>
                                
                                <div class="tool-card">
                                    <h4 class="tool-card-title">
                                        <i class="fas fa-lock"></i>
                                        加密/解密
                                    </h4>
                                    <textarea class="tool-input" id="cryptoInput" placeholder="输入要加密/解密的文本..." rows="4">Hello, 菜籽游!</textarea>
                                    <div class="tool-buttons">
                                        <button class="tool-btn" id="encryptBtn">Base64加密</button>
                                        <button class="tool-btn" id="decryptBtn">Base64解密</button>
                                        <button class="tool-btn" id="hashBtn">MD5哈希</button>
                                    </div>
                                    <div class="tool-output" id="cryptoOutput"></div>
                                </div>
                                
                                <div class="tool-card">
                                    <h4 class="tool-card-title">
                                        <i class="fas fa-ruler"></i>
                                        单位转换
                                    </h4>
                                    <input type="number" class="tool-input" id="unitValue" placeholder="输入数值" value="100">
                                    <div class="tool-buttons">
                                        <button class="tool-btn" id="pxToRemBtn">PX → REM</button>
                                        <button class="tool-btn" id="remToPxBtn">REM → PX</button>
                                        <button class="tool-btn" id="celsiusToFahrenheitBtn">°C → °F</button>
                                    </div>
                                    <div class="tool-output" id="unitOutput"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="tool-section">
                            <h4 class="tool-section-title">
                                <i class="fas fa-paint-brush"></i>
                                设计工具
                            </h4>
                            <div class="tool-grid">
                                <div class="tool-card">
                                    <h4 class="tool-card-title">
                                        <i class="fas fa-palette"></i>
                                        颜色选择器
                                    </h4>
                                    <input type="color" class="tool-input" id="colorPicker" value="#45f3ff" style="height: 40px; padding: 0;">
                                    <div class="tool-buttons">
                                        <button class="tool-btn" id="copyHexBtn">复制HEX</button>
                                        <button class="tool-btn" id="copyRgbBtn">复制RGB</button>
                                        <button class="tool-btn" id="randomColorBtn">随机颜色</button>
                                    </div>
                                    <div class="tool-output" id="colorOutput">HEX: #45f3ff<br>RGB: rgb(69, 243, 255)</div>
                                </div>
                                
                                <div class="tool-card">
                                    <h4 class="tool-card-title">
                                        <i class="fas fa-image"></i>
                                        图片处理
                                    </h4>
                                    <input type="file" class="tool-input" id="imageUpload" accept="image/*" style="padding: 8px;">
                                    <div class="tool-buttons">
                                        <button class="tool-btn" id="resizeImageBtn">调整尺寸</button>
                                        <button class="tool-btn" id="compressImageBtn">压缩图片</button>
                                        <button class="tool-btn" id="convertFormatBtn">转换格式</button>
                                    </div>
                                    <div class="tool-output" id="imageOutput">选择图片后进行操作</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 原有公共服务 -->
                        <div class="tool-section">
                            <h4 class="tool-section-title">
                                <i class="fas fa-server"></i>
                                平台服务
                            </h4>
                            <div class="service-list">
                                <div class="service-item">
                                    <div class="service-icon">
                                        <i class="fas fa-cloud-upload-alt"></i>
                                    </div>
                                    <div class="service-content">
                                        <h4 class="service-title">文件存储</h4>
                                        <p class="service-description">
                                            安全可靠的文件存储服务，支持多种格式，随时随地访问你的文件。
                                        </p>
                                    </div>
                                </div>
                                
                                <div class="service-item">
                                    <div class="service-icon">
                                        <i class="fas fa-code"></i>
                                    </div>
                                    <div class="service-content">
                                        <h4 class="service-title">代码托管</h4>
                                        <p class="service-description">
                                            Git代码托管服务，支持私有仓库、团队协作和CI/CD集成。
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content <?php echo $currentTab === 'discover' ? 'active' : ''; ?>" id="tab-discover">
                        <h3 class="tab-title">
                            <i class="fas fa-compass"></i>
                            发现 · 团推流
                        </h3>
                        <div class="feed-container" id="feedList">
                            <div class="placeholder-box">
                                <i class="fas fa-broadcast-tower"></i>
                                <p>团推流功能正在开发中，敬请期待...</p>
                                <span class="placeholder-label">即将上线</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 节点/代理已合并到服务 tab -->
                    <!-- 工具箱已合并到服务 tab -->
                    
                    <!-- 管理员面板 -->
                    <div class="tab-content <?php echo $currentTab === 'admin' ? 'active' : ''; ?>" id="tab-admin">
                        <div id="pendingUsersList">
                            <div style="text-align:center;padding:30px;color:#888;"><i class="fas fa-spinner fa-spin"></i> 加载中...</div>
                        </div>
                    </div>
                    
                    <!-- 消息 -->
                    <div class="tab-content" id="tab-chat">
                        <h3 class="tab-title">
                            <i class="fas fa-comment-dots"></i>
                            消息
                        </h3>
                        <div class="chat-body-inline">
                            <div class="chat-sidebar-inline">
                                <div class="chat-tabs">
                                    <button class="chat-tab active" data-chat-tab="friends">好友</button>
                                    <button class="chat-tab" data-chat-tab="requests">申请</button>
                                </div>
                                <div class="chat-list" id="friendList"></div>
                                <div class="chat-list" id="requestList" style="display:none;"></div>
                            </div>
                            <div class="chat-area-inline">
                                <div class="chat-conversation" id="chatConversation"></div>
                                <div class="chat-input-area">
                                    <textarea id="chatInput" placeholder="输入消息..."></textarea>
                                    <button id="sendChatBtn">发送</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
    
    <!-- 消息已移到内容区 tab-chat -->
    
    <!-- 名片浮窗 -->
    <div class="card-modal" id="cardModal">
        <div class="card-modal-content">
            <span class="close-card">&times;</span>
            <div class="card-info">
                <img src="" alt="" id="cardAvatar">
                <h3 id="cardUsername"></h3>
                <p id="cardBio"></p>
                <button id="addFriendBtn">添加好友</button>
            </div>
        </div>
    </div>
    
    <!-- 设置浮窗 -->
    <div class="settings-modal" id="settingsModal">
        <div class="settings-modal-content">
            <span class="close-settings">&times;</span>
            <h3>个人信息设置</h3>
            <form id="settingsForm">
                <label class="form-label">昵称</label>
                <input type="text" id="settingsNickname" class="settings-input" placeholder="你的昵称" value="<?php echo htmlspecialchars($currentUser['nickname']); ?>">
                
                <label class="form-label">个人简介</label>
                <textarea id="settingsBio" class="settings-textarea" placeholder="说点什么..."><?php echo htmlspecialchars($currentUser['bio'] ?? ''); ?></textarea>
                
                <button type="submit" class="save-btn">保存</button>
            </form>
        </div>
    </div>
    
    <script>
    // ============================================================
    // 菜籽游 完整应用脚本 — 侧边栏/私聊/设置/推流/团广场
    // ============================================================

    var CURRENT_USER_ID = <?php echo $userId ?? 0; ?>;
    var CURRENT_CHAT_ID = null;
    var CHAT_POLL = null;

    // ---- 侧边栏切换 ----
    function initClicks() {
        console.log('[DIAG] initClicks start');
        var sidebarItems = document.querySelectorAll('.sidebar-item');
        console.log('[DIAG] sidebar items found:', sidebarItems.length);
        for (var i = 0; i < sidebarItems.length; i++) {
            (function(item) {
                item.style.cursor = 'pointer';
                item.onclick = function() {
                    for (var j = 0; j < sidebarItems.length; j++)
                        sidebarItems[j].classList.remove('active');
                    item.classList.add('active');

                    var tab = item.getAttribute('data-tab');

                    // 聊天不是普通tab，直接弹模态框并保持当前tab激活
                    if (tab === 'chat') {
                        openChat(null, null);
                        return;
                    }

                    var tabContents = document.querySelectorAll('.tab-content');
                    for (var k = 0; k < tabContents.length; k++) {
                        tabContents[k].classList.remove('active');
                        if (tabContents[k].id === 'tab-' + tab)
                            tabContents[k].classList.add('active');
                    }

                    if (tab === 'service') { if (typeof initToolbox === 'function') initToolbox(); initProxyNodes(); }
                    if (tab === 'discover') { loadFeedList(); }
                    if (tab === 'admin' && typeof initAdminPanel === 'function') initAdminPanel();
                    if (tab === 'group') { bindGroupSubtabs(); loadCommunityList(); }
                };
            })(sidebarItems[i]);
        }
        bindGroupSubtabs();
        loadCommunityList();
        // Feed moved to discover tab, load it as default
        loadFeedList();
    }

    // ---- 团子标签切换 ----
    function bindGroupSubtabs() {
        var subtabs = document.querySelectorAll('.subtab-item');
        for (var i = 0; i < subtabs.length; i++) {
            (function(s) {
                s.style.cursor = 'pointer';
                s.onclick = function() {
                    for (var j = 0; j < subtabs.length; j++) subtabs[j].classList.remove('active');
                    s.classList.add('active');
                    var name = s.getAttribute('data-subtab');
                    document.querySelectorAll('.group-subcontent').forEach(function(el) {
                        el.classList.remove('active');
                        if (el.id === 'group-' + name) el.classList.add('active');
                    });
                };
            })(subtabs[i]);
        }
    }

    // ---- 加载团广场 ----
    function loadCommunityList() {
        var el = document.getElementById('communityList');
        if (!el) return;
        fetch('/api/community/list').then(function(r) { return r.json(); }).then(function(d) {
            if (!d.success || !d.communities || d.communities.length === 0) return;
            var html = '';
            d.communities.forEach(function(c) {
                html += '<div class="community-card">' +
                    '<div class="community-header">' +
                    '<div class="community-avatar" style="background:#45f3ff;display:flex;align-items:center;justify-content:center;">' +
                    '<i class="fas fa-users" style="color:#000;font-size:20px;"></i></div>' +
                    '<div class="community-info"><div class="community-name">' + escapeHtml(c.name) + '</div>' +
                    '<span class="community-category">' + escapeHtml(c.category || '其他') + '</span></div></div>' +
                    '<div class="community-description">' + escapeHtml(c.description || '暂无简介') + '</div>' +
                    '<div class="community-stats">' +
                    '<span class="stat-item"><i class="fas fa-user"></i> ' + (c.member_count || 1) + '</span>' +
                    '<span class="stat-item"><i class="fas fa-clock"></i> ' + escapeHtml(c.created_at || '') + '</span></div></div>';
            });
            el.innerHTML = html;
        }).catch(function() {});
    }

    // ---- 加载推流 ----
    function loadFeedList() {
        console.log('[DIAG] loadFeedList start');
        var el = document.getElementById('feedList');
        console.log('[DIAG] feedList element:', !!el);
        if (!el) { console.log('[DIAG] feedList NOT FOUND - returning'); return; }
        fetch('/api/feed/list').then(function(r) { return r.json(); }).then(function(d) {
            console.log('[DIAG] feed API response:', d.success, 'feeds:', d.feeds ? d.feeds.length : 0);
            if (!d.success || !d.feeds || d.feeds.length === 0) { console.log('[DIAG] no feeds or failed'); return; }
            var html = '';
            d.feeds.forEach(function(f) {
                var content = f.activity_data ? (typeof f.activity_data === 'string' ? f.activity_data : JSON.stringify(f.activity_data)) : '';
                html += '<div class="feed-item">' +
                    '<div class="feed-header">' +
                    '<div class="feed-avatar" style="background:#45f3ff;display:flex;align-items:center;justify-content:center;">' +
                    '<i class="fas fa-user" style="color:#000;"></i></div>' +
                    '<div class="feed-user"><div class="feed-username">' + escapeHtml(f.nickname || f.username) + '</div>' +
                    '<div class="feed-time">' + escapeHtml(f.created_at || '') + '</div></div></div>' +
                    '<div class="feed-content"><div class="feed-text">' + escapeHtml(content || '发布了一条动态') + '</div>' +
                    '<div class="feed-media"><i class="fas fa-image"></i> 媒体占位</div></div>' +
                    '<div class="feed-actions">' +
                    '<span class="feed-action"><i class="far fa-heart"></i> ' + (f.likes || 0) + '</span>' +
                    '<span class="feed-action"><i class="far fa-comment"></i> ' + (f.comments || 0) + '</span></div></div>';
            });
            el.innerHTML = html;
            console.log('[DIAG] feedList rendered, items:', (html.match(/feed-item/g) || []).length);
        }).catch(function(err) { console.log('[DIAG] feed fetch catch:', err && err.message); });
    }

    // ============================================================
    // 私聊系统
    // ============================================================

    function openChat(userId, userName) {
        // 切换到消息tab
        var sidebarItems = document.querySelectorAll('.sidebar-item');
        for (var i = 0; i < sidebarItems.length; i++) {
            sidebarItems[i].classList.remove('active');
        }
        var chatSidebar = document.getElementById('sidebarChatBtn');
        if (chatSidebar) chatSidebar.classList.add('active');
        
        var tabContents = document.querySelectorAll('.tab-content');
        for (var i = 0; i < tabContents.length; i++) {
            tabContents[i].classList.remove('active');
            if (tabContents[i].id === 'tab-chat')
                tabContents[i].classList.add('active');
        }

        // 加载好友列表
        loadFriendList();

        // 如果有指定用户，创建会话
        if (userId && userId != CURRENT_USER_ID) {
            fetch('/api/chat/create', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({user_id: CURRENT_USER_ID, target_id: userId})
            }).then(function(r) { return r.json(); }).then(function(d) {
                if (d.success) {
                    CURRENT_CHAT_ID = d.chat_id;
                    loadMessages();
                    var chatHeader = document.querySelector('.chat-header-inline h3') || document.querySelector('.tab-chat-header');
                    if (chatHeader) chatHeader.textContent = '与 ' + (userName || '用户') + ' 的会话';
                }
            }).catch(function() {});
        } else {
            // 默认加载已有会话
            loadConversations();
        }
    }

    function loadFriendList() {
        var el = document.getElementById('friendList');
        if (!el) return;
        fetch('/api/friends/list').then(function(r) { return r.json(); }).then(function(d) {
            if (!d.success) return;
            var html = '';
            d.users.forEach(function(u) {
                if (u.id == CURRENT_USER_ID) return;
                var safeName = escapeHtml(u.nickname || u.username);
                html += '<div class="chat-user-item" onclick="openChat(' + u.id + ', \'' + safeName + '\')" style="padding:10px;cursor:pointer;border-bottom:1px solid rgba(69,243,255,0.1);display:flex;align-items:center;gap:10px;">' +
                    '<div style="width:36px;height:36px;border-radius:50%;background:#45f3ff;display:flex;align-items:center;justify-content:center;flex-shrink:0;">' +
                    '<i class="fas fa-user" style="color:#000;font-size:14px;"></i></div>' +
                    '<div><div style="color:#fff;font-size:14px;">' + escapeHtml(u.nickname || u.username) + '</div>' +
                    '<div style="color:#888;font-size:12px;">@' + escapeHtml(u.username) + '</div></div></div>';
            });
            el.innerHTML = html;
        }).catch(function() {});
    }

    function loadConversations() {
        var el = document.getElementById('friendList');
        if (!el) return;
        fetch('/api/chat/conversations?user_id=' + CURRENT_USER_ID).then(function(r) { return r.json(); }).then(function(d) {
            if (!d.success || !d.chats || d.chats.length === 0) {
                if (window.__toast) window.__toast('暂无会话，点击好友开始聊天');
                return;
            }
            var html = '';
            d.chats.forEach(function(c) {
                var u = c.other_user || {};
                var name = u.nickname || u.username || '用户';
                var unreadBadge = c.unread > 0 ? '<span style="background:#ff2770;color:#fff;border-radius:50%;padding:2px 8px;font-size:11px;">' + c.unread + '</span>' : '';
                html += '<div class="chat-user-item" onclick="openChatById(' + c.chat_id + ')"' +
                    'style="padding:10px;cursor:pointer;border-bottom:1px solid rgba(69,243,255,0.1);display:flex;align-items:center;gap:10px;">' +
                    '<div style="width:36px;height:36px;border-radius:50%;background:#45f3ff;display:flex;align-items:center;justify-content:center;flex-shrink:0;">' +
                    '<i class="fas fa-user" style="color:#000;font-size:14px;"></i></div>' +
                    '<div style="flex:1;"><div style="color:#fff;font-size:14px;">' + escapeHtml(name) + unreadBadge + '</div>' +
                    '<div style="color:#666;font-size:12px;">' + escapeHtml(c.last_msg || '...') + '</div></div></div>';
            });
            el.innerHTML = html;
            var total = d.total_unread || 0;
            if (total > 0) {
                document.querySelector('.bottom-left .msg-input').innerHTML = '<i class="fas fa-comment"></i> 消息 <span style="background:#ff2770;color:#fff;border-radius:10px;padding:1px 8px;font-size:11px;">' + total + '</span>';
            }
        }).catch(function() {});
    }

    function openChatById(chatId) {
        CURRENT_CHAT_ID = chatId;
        // 切换到消息tab
        var sidebarItems = document.querySelectorAll('.sidebar-item');
        for (var i = 0; i < sidebarItems.length; i++) {
            sidebarItems[i].classList.remove('active');
        }
        var chatSidebar = document.getElementById('sidebarChatBtn');
        if (chatSidebar) chatSidebar.classList.add('active');
        var tabContents = document.querySelectorAll('.tab-content');
        for (var i = 0; i < tabContents.length; i++) {
            tabContents[i].classList.remove('active');
            if (tabContents[i].id === 'tab-chat')
                tabContents[i].classList.add('active');
        }
        loadMessages();
        var chatH = document.querySelector('.chat-header-inline h3');
        if (chatH) chatH.textContent = '会话';
    }

    function loadMessages() {
        var el = document.getElementById('chatConversation');
        if (!el || !CURRENT_CHAT_ID) return;
        fetch('/api/chat/messages?chat_id=' + CURRENT_CHAT_ID).then(function(r) { return r.json(); }).then(function(d) {
            if (!d.success) return;
            var html = '';
            d.messages.forEach(function(m) {
                var isMe = m.sender_id == CURRENT_USER_ID;
                var align = isMe ? 'right' : 'left';
                var bg = isMe ? '#45f3ff' : '#2a2a3a';
                var tc = isMe ? '#000' : '#fff';
                html += '<div style="text-align:' + align + ';margin:6px 0;">' +
                    '<span style="display:inline-block;max-width:70%;padding:8px 14px;border-radius:12px;background:' + bg + ';color:' + tc + ';font-size:14px;line-height:1.4;">' +
                    escapeHtml(m.content) + '</span>' +
                    '<div style="font-size:11px;color:#666;margin-top:2px;">' + escapeHtml(m.created_at || '') + '</div></div>';
            });
            el.innerHTML = html;
            el.scrollTop = el.scrollHeight;
        }).catch(function() {});
    }

    function sendChatMessage() {
        var input = document.getElementById('chatInput');
        if (!input || !CURRENT_CHAT_ID) return;
        var content = input.value.trim();
        if (!content) return;
        input.value = '';
        fetch('/api/chat/send', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({chat_id: CURRENT_CHAT_ID, sender_id: CURRENT_USER_ID, content: content})
        }).then(function(r) { return r.json(); }).then(function(d) {
            if (d.success) loadMessages();
        }).catch(function() {});
    }

    // ---- Canvas背景 ----
    var canvas = document.getElementById('bgCanvas');
    if (canvas) {
        var ctx = canvas.getContext('2d');
        function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
        resize();
        window.addEventListener('resize', resize);
        function draw() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            var gs = 40, ox = (Date.now() * 0.005) % gs, oy = (Date.now() * 0.005) % gs;
            ctx.strokeStyle = 'rgba(69,243,255,0.03)';
            ctx.lineWidth = 0.5;
            for (var x = ox; x < canvas.width; x += gs) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke(); }
            for (var y = oy; y < canvas.height; y += gs) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke(); }
            requestAnimationFrame(draw);
        }
        draw();
    }

    // ---- 设置保存 ----
    (function() {
        var form = document.getElementById('settingsForm');
        if (!form) return;
        form.onsubmit = function(e) {
            e.preventDefault();
            var nickname = document.getElementById('settingsNickname').value.trim();
            var bio = document.getElementById('settingsBio').value.trim();
            fetch('/api/user/update-profile', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({user_id: CURRENT_USER_ID, nickname: nickname, bio: bio})
            }).then(function(r) { return r.json(); }).then(function(d) {
                var msg = document.createElement('div');
                msg.style.cssText = 'text-align:center;margin-top:10px;font-size:14px;';
                msg.style.color = d.success ? '#00c853' : '#ff4444';
                msg.textContent = d.success ? '✅ 保存成功' : '❌ ' + (d.error || '失败');
                form.appendChild(msg);
                setTimeout(function() { msg.remove(); }, 2000);
            }).catch(function() {});
        };
    })();

    // ---- 聊天绑定（内容区tab） ----
    (function() {
        document.getElementById('sidebarChatBtn').onclick = function() {
            openChat(null, null);
        };
        document.getElementById('sendChatBtn').onclick = sendChatMessage;
        document.getElementById('chatInput').addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
        });
        // 聊天tab切换
        var chatTabs = document.querySelectorAll('.chat-tab');
        for (var i = 0; i < chatTabs.length; i++) {
            (function(ct) {
                ct.onclick = function() {
                    for (var j = 0; j < chatTabs.length; j++) chatTabs[j].classList.remove('active');
                    ct.classList.add('active');
                    var target = ct.getAttribute('data-chat-tab');
                    document.getElementById('friendList').style.display = (target === 'friends' ? 'block' : 'none');
                    document.getElementById('requestList').style.display = (target === 'requests' ? 'block' : 'none');
                };
            })(chatTabs[i]);
        }
        // 打开聊天时启动轮询
        var origOpen = openChat;
        window.openChat = function(uid, name) {
            if (CHAT_POLL) clearInterval(CHAT_POLL);
            origOpen(uid, name);
            CHAT_POLL = setInterval(function() { if (CURRENT_CHAT_ID) loadMessages(); }, 3000);
        };
        window.openChatById = function(cid) {
            if (CHAT_POLL) clearInterval(CHAT_POLL);
            CURRENT_CHAT_ID = cid;
            loadMessages();
            document.querySelector('.chat-header-inline h3').textContent = '会话';
            CHAT_POLL = setInterval(function() { loadMessages(); }, 3000);
        };
    })();

    // ---- 设置模态框 ----
    (function() {
        var modal = document.getElementById('settingsModal');
        if (!modal) return;
        document.querySelector('.close-settings').onclick = function() {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        };
        // 点击右上角用户名打开设置
        var userBtn = document.querySelector('.top-bar .user-info, .top-bar .username');
        if (userBtn) {
            userBtn.style.cursor = 'pointer';
            userBtn.onclick = function() {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            };
        }
    })();

    // ---- 工具函数 ----
    function escapeHtml(s) {
        if (!s) return '';
        var d = document.createElement('div');
        d.appendChild(document.createTextNode(String(s)));
        return d.innerHTML;
    }

    function initToolbox() {
        if (typeof window.initToolboxExternal === 'function') {
            window.initToolboxExternal();
            if (window.__toast) window.__toast('工具箱已初始化');
        }
    }
    function initAdminPanel() {
        if (typeof window.initAdminPanelExternal === 'function') {
            window.initAdminPanelExternal();
            if (window.__toast) window.__toast('管理员面板已初始化');
        }
    }
    function initProxyNodes() {
        var el = document.getElementById('proxyNodesList');
        if (!el) return;
        var subUrl = window.location.origin + '/sub/node.txt';
        var confUrl = window.location.origin + '/sub/client.conf';
        var tutUrl = window.location.origin + '/sub/';
        el.innerHTML =
            '<div style="padding:10px 0;">' +
            '<div style="background:rgba(0,0,0,0.3);border:1px solid #45f3ff;border-radius:8px;padding:20px;margin-bottom:12px;">' +
            '<h4 style="color:#45f3ff;margin-bottom:10px;"><i class="fas fa-shield-alt"></i> WireGuard 隧道</h4>' +
            '<p style="color:#aaa;font-size:13px;">地址: 154.64.255.112 : 51820</p>' +
            '<p style="color:#aaa;font-size:13px;">内网: 10.0.0.2/24 | MTU: 1420</p>' +
            '</div>' +
            '<div style="background:rgba(0,0,0,0.3);border:1px solid #e87a8a;border-radius:8px;padding:20px;margin-bottom:12px;text-align:center;">' +
            '<p style="color:#ccc;margin-bottom:10px;font-size:14px;">📋 订阅链接（Karing 导入）</p>' +
            '<div style="background:#0a0a0f;padding:10px;border-radius:6px;word-break:break-all;font-size:12px;color:#45f3ff;margin-bottom:10px;">' + subUrl + '</div>' +
            '<a href="' + tutUrl + '" target="_blank" style="display:inline-block;background:#45f3ff;color:#000;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:bold;font-size:14px;margin-right:8px;"><i class="fas fa-book"></i> 配置教程</a>' +
            '<a href="' + confUrl + '" download style="display:inline-block;background:#e87a8a;color:#000;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:bold;font-size:14px;"><i class="fas fa-download"></i> 下载配置</a>' +
            '</div>' +
            '</div>';
        if (window.__toast) window.__toast('节点信息已加载');
    }

    // ---- 启动 ----
    function startApp() {
        console.log('[DIAG] startApp begin');
        if (typeof initClicks === 'function') { console.log('[DIAG] calling initClicks'); initClicks(); } else console.log('[DIAG] initClicks NOT FOUND');
        console.log('[DIAG] initClicks done, sidebarItems:', document.querySelectorAll('.sidebar-item').length);
        if (typeof initToolbox === 'function') { console.log('[DIAG] calling initToolbox'); initToolbox(); } else console.log('[DIAG] initToolbox NOT FOUND');
        if (typeof initAdminPanel === 'function') { console.log('[DIAG] calling initAdminPanel'); initAdminPanel(); } else console.log('[DIAG] initAdminPanel NOT FOUND');
        if (typeof loadConversations === 'function') { console.log('[DIAG] calling loadConversations'); loadConversations(); } else console.log('[DIAG] loadConversations NOT FOUND');
        console.log('[DIAG] startApp complete');
        if (window.__toast) window.__toast('✅ 应用已启动');
    }

    if (document.readyState === 'complete') {
        startApp();
    } else {
        window.addEventListener('load', startApp);
    }
    </script>
    
    <!-- 创建团模态框 -->
    <div id="createGroupModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.75);z-index:9999;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div class="silicone-modal">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                <h3 style="margin:0;color:#fff;"><i class="fas fa-plus-circle" style="color:var(--accent);margin-right:8px;"></i>创建团</h3>
                <span id="closeGroupModal" style="cursor:pointer;font-size:28px;color:#666;line-height:1;transition:color 0.2s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#666'">&times;</span>
            </div>
            <div class="silicone-form-group">
                <label class="silicone-label">团名称 <span style="color:#ff4444;">*</span></label>
                <input type="text" id="createGroupName" class="silicone-input" placeholder="输入团名称" maxlength="50">
            </div>
            <div class="silicone-form-group">
                <label class="silicone-label">团简介</label>
                <textarea id="createGroupDesc" class="silicone-input" placeholder="介绍一下这个团..." rows="3" style="resize:vertical;min-height:80px;"></textarea>
            </div>
            <div class="silicone-form-group">
                <label class="silicone-label">团分类</label>
                <select id="createGroupCategory" class="silicone-input">
                    <option value="">选择分类</option>
                    <option value="tech">科技/技术</option>
                    <option value="game">游戏</option>
                    <option value="art">艺术/设计</option>
                    <option value="music">音乐</option>
                    <option value="sports">运动</option>
                    <option value="study">学习/教育</option>
                    <option value="life">生活/日常</option>
                    <option value="other">其他</option>
                </select>
            </div>
            <button id="submitCreateGroup" class="silicone-btn" style="width:100%;margin-top:8px;">
                <i class="fas fa-paper-plane"></i> 提交申请
            </button>
            <div id="createGroupMsg" style="margin-top:10px;font-size:13px;text-align:center;min-height:20px;"></div>
        </div>
    </div>
    
    <style>
    /* 奶白硅胶UI表单样式 */
    .silicone-modal {
        background: linear-gradient(145deg, #1a1a24, #222230);
        border-radius: 20px;
        padding: 30px 28px;
        width: 90%;
        max-width: 420px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(69,243,255,0.1);
        animation: modalSlideIn 0.3s ease;
    }
    @keyframes modalSlideIn {
        from { opacity: 0; transform: translateY(30px) scale(0.95); }
        to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .silicone-form-group {
        margin-bottom: 16px;
    }
    .silicone-label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        color: #aaa;
        margin-bottom: 6px;
    }
    .silicone-input {
        width: 100%;
        padding: 12px 14px;
        background: rgba(255,255,255,0.06);
        border: 1.5px solid rgba(255,255,255,0.1);
        border-radius: 12px;
        font-size: 15px;
        color: #eee;
        outline: none;
        box-shadow: inset 0 2px 6px rgba(0,0,0,0.3);
        transition: border-color 0.2s, box-shadow 0.2s;
        box-sizing: border-box;
        font-family: inherit;
    }
    .silicone-input:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px rgba(69,243,255,0.1), inset 0 2px 6px rgba(0,0,0,0.3);
    }
    .silicone-input::placeholder {
        color: #666;
    }
    .silicone-btn {
        padding: 12px 24px;
        background: linear-gradient(135deg, #45f3ff, #2ecee0);
        color: #000;
        border: none;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.15s, box-shadow 0.15s;
        font-family: inherit;
    }
    .silicone-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(69,243,255,0.3);
    }
    .silicone-btn:active {
        transform: translateY(0);
    }
    .silicone-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
        transform: none;
    }
    textarea.silicone-input {
        font-family: inherit;
    }
    select.silicone-input {
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath d='M2 4l4 4 4-4' fill='none' stroke='%23666' stroke-width='1.5'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 14px center;
        padding-right: 36px;
    }
    </style>
    
    <script>
    // 创建团模态框逻辑
    (function(){
        var createBtn = document.getElementById('createGroupBtn');
        var modal = document.getElementById('createGroupModal');
        var closeBtn = document.getElementById('closeGroupModal');
        var submitBtn = document.getElementById('submitCreateGroup');
        var nameInput = document.getElementById('createGroupName');
        var descInput = document.getElementById('createGroupDesc');
        var catSelect = document.getElementById('createGroupCategory');
        var msgEl = document.getElementById('createGroupMsg');
        
        if (!createBtn || !modal) return;
        
        function openModal() {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            nameInput.focus();
        }
        function closeModal() {
            modal.style.display = 'none';
            document.body.style.overflow = '';
            msgEl.textContent = '';
        }
        
        createBtn.onclick = openModal;
        if (closeBtn) closeBtn.onclick = closeModal;
        modal.onclick = function(e) { if (e.target === modal) closeModal(); };
        
        submitBtn.onclick = function() {
            var name = nameInput.value.trim();
            if (!name) {
                msgEl.innerHTML = '<span style="color:#ff4444;">请输入团名称</span>';
                nameInput.focus();
                return;
            }
            msgEl.innerHTML = '<span style="color:#888;">提交中...</span>';
            submitBtn.disabled = true;
            
            fetch('/api/community/create', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    creator_id: <?php echo $userId; ?>,
                    name: name,
                    description: descInput.value.trim(),
                    category: catSelect.value || 'other'
                })
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                submitBtn.disabled = false;
                if (data.success) {
                    msgEl.innerHTML = '<span style="color:#00c853;">✅ ' + data.message + '</span>';
                    nameInput.value = ''; descInput.value = ''; catSelect.value = '';
                    setTimeout(closeModal, 1500);
                } else {
                    msgEl.innerHTML = '<span style="color:#ff4444;">❌ ' + (data.error || '创建失败') + '</span>';
                }
            })
            .catch(function() {
                submitBtn.disabled = false;
                msgEl.innerHTML = '<span style="color:#ff4444;">❌ 网络请求失败</span>';
            });
        };
        
        nameInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') submitBtn.click();
        });
    })();
    </script>
    
    <!-- 统一点页脚 -->
    <footer id="appFooter" style="display:none;text-align:center;padding:16px 20px;background:#eeeef0;border-top:1px solid rgba(60,60,67,0.06);color:#7c7c82;font-size:13px;">
        <span>&copy; 2026 菜籽游 &middot; 纵流</span>
        <span style="margin:0 10px;color:#d1d1d6;">|</span>
        <span>开放 · 聚合 · 创造</span>
    </footer>
    
    <script>
    // 显示页脚（有些页面可能有全屏canvas需要不显示）
    setTimeout(function() {
        var f = document.getElementById('appFooter');
        if (f) f.style.display = 'block';
    }, 500);
    </script>
</body>
</html>