/* ===== 菜籽游 App — 纯前端逻辑 ===== */
/* ===== 配置 ===== */


let CURRENT_CHAT_ID = null;
let CHAT_POLL = null;
let ADMIN_TOKEN = sessionStorage.getItem('admin_token') || '';
let JUNIUS_POLL = null;

function byId(id){return document.getElementById(id)}
function qs(s,c){return(c||document).querySelector(s)}
function qsa(s,c){return(c||document).querySelectorAll(s)}
function esc(s){var d=document.createElement('div');d.appendChild(document.createTextNode(String(s)));return d.innerHTML}
function toast(m){
  var t=byId('toast');if(!t){t=document.createElement('div');t.id='toast';t.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1e1e2a;color:#eee;padding:10px 20px;border-radius:8px;z-index:99999;font-size:13px;border:1px solid #2a2a3a;transition:opacity.3s';document.body.appendChild(t)}
  t.textContent=m;t.style.opacity='1';clearTimeout(t._t);t._t=setTimeout(function(){t.style.opacity='0'},2500)
}

/* ===== 面板切换 ===== */
function showPanel(name){
  qsa('.float-panel').forEach(function(p){p.classList.remove('active')});
  var def=byId('panelDefault');if(def)def.style.display='none';
  var p=byId('panel-'+name);if(p)p.classList.add('active');
}
function togglePanel(name){
  var p=byId('panel-'+name);if(!p)return;
  if(p.classList.contains('active')){
    p.classList.remove('active');var def=byId('panelDefault');if(def)def.style.display='';
    qsa('.sidebar-item').forEach(function(s){s.classList.remove('active')});
  }else showPanel(name);
}

/* ===== 侧边栏 ===== */
function initSidebar(){
  if(USER_ROLE!=='admin'){var a=qsa('.admin-only');a.forEach(function(el){el.style.display='none'})}
  qsa('.sidebar-item').forEach(function(item){
    item.onclick=function(){
      qsa('.sidebar-item').forEach(function(s){s.classList.remove('active')});
      item.classList.add('active');var tab=item.getAttribute('data-tab');
      showPanel(tab);
      if(tab==='discover')loadFeed();
      if(tab==='service'){renderService();}
      if(tab==='group')renderCommunity();
      if(tab==='chat'){initChat();}
      if(tab==='admin')renderAdmin();
    };
  });
  loadFeed(); // 默认加载
}

/* ===== 发现 ===== */
function loadFeed(){
  var el=byId('feedList');if(!el)return;
  fetch('/api/feed/list').then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.feeds||!d.feeds.length){el.innerHTML='<div class="placeholder-box"><i class="fas fa-broadcast-tower"></i><p>暂无动态</p></div>';return}
    el.innerHTML=d.feeds.map(function(f){return'<div class="feed-item"><div class="feed-user">'+esc(f.nickname||f.username)+'</div><div class="feed-content">'+esc(f.content||'')+'</div><div class="feed-time">'+esc(f.created_at||'')+'</div></div>'}).join('');
  }).catch(function(){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>'});
}

/* ===== 服务 ===== */
function renderService(){
  var el=byId('serviceContent');if(!el||el.dataset.rendered)return;el.dataset.rendered='1';
  el.innerHTML=
    '<div class="tool-section"><h4 class="tool-section-title"><i class="fas fa-satellite-dish"></i> VPN节点</h4><div class="proxy-card"><h4><i class="fas fa-shield-alt"></i> 纵流-WireGuard</h4><p>地址: 154.64.255.112:51820</p><p>内网: 10.0.0.2/24</p><div style="display:flex;gap:8px;margin-top:10px"><a href="/sub/clash.yaml" class="btn btn-sm" target="_blank"><i class="fas fa-download"></i> Clash</a><a href="/sub/client.conf" class="btn btn-sm" target="_blank"><i class="fas fa-download"></i> WireGuard</a><a href="/sub/" class="btn btn-sm" target="_blank"><i class="fas fa-book"></i> 教程</a></div></div><div style="margin-top:8px"><a href="/downloads/agent-client.exe" class="btn btn-sm btn-accent"><i class="fas fa-download"></i> 下载 Agent Client (Windows)</a></div></div>'+
    '<div class="tool-section"><h4 class="tool-section-title"><i class="fas fa-tools"></i> 在线工具箱</h4><div class="tool-grid">'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-hashtag"></i> JSON</h4><textarea id="jsonInput" rows="3" placeholder="输入JSON..."></textarea><div class="tool-buttons"><button class="btn btn-sm" id="formatJsonBtn">格式化</button><button class="btn btn-sm" id="minifyJsonBtn">压缩</button><button class="btn btn-sm" id="validateJsonBtn">验证</button></div><div class="tool-output" id="jsonOutput"></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-lock"></i> Base64</h4><textarea id="cryptoInput" rows="3" placeholder="输入文本..."></textarea><div class="tool-buttons"><button class="btn btn-sm" id="encryptBtn">编码 →</button><button class="btn btn-sm" id="decryptBtn">解码 →</button></div><div class="tool-output" id="cryptoOutput"></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-ruler"></i> 单位换算</h4><input id="unitValue" placeholder="数值"><div class="form-row" style="margin:4px 0"><select id="unitType"><option value="length">长度</option><option value="temp">温度</option></select><select id="unitFrom"><option value="m">米</option><option value="cm">厘米</option></select><select id="unitTo"><option value="cm">厘米</option><option value="m">米</option></select></div><button class="btn btn-sm" id="convertUnitBtn">换算</button><div class="tool-output" id="unitOutput"></div></div>'+
    '<div class="tool-card"><h4 class="tool-card-title"><i class="fas fa-palette"></i> 颜色</h4><input type="color" id="colorPicker" value="#45f3ff" style="height:40px;padding:0"><div class="tool-buttons"><button class="btn btn-sm" id="copyHexBtn">HEX</button><button class="btn btn-sm" id="copyRgbBtn">RGB</button><button class="btn btn-sm" id="randomColorBtn">随机</button></div><div class="tool-output" id="colorOutput">HEX: #45f3ff</div></div>'+
    '</div></div>';
  bindTools();
}
function bindTools(){
  var f=byId('formatJsonBtn');if(f)f.onclick=function(){var i=byId('jsonInput'),o=byId('jsonOutput');if(!i||!o)return;try{o.textContent=JSON.stringify(JSON.parse(i.value),null,2)}catch(e){o.textContent='❌ '+e.message}};
  var m=byId('minifyJsonBtn');if(m)m.onclick=function(){var i=byId('jsonInput'),o=byId('jsonOutput');if(!i||!o)return;try{o.textContent=JSON.stringify(JSON.parse(i.value))}catch(e){o.textContent='❌ '+e.message}};
  var v=byId('validateJsonBtn');if(v)v.onclick=function(){var i=byId('jsonInput'),o=byId('jsonOutput');if(!i||!o)return;try{JSON.parse(i.value);o.textContent='✅ 有效'}catch(e){o.textContent='❌ '+e.message}};
  var enc=byId('encryptBtn');if(enc)enc.onclick=function(){var i=byId('cryptoInput'),o=byId('cryptoOutput');if(!i||!o)return;o.textContent=btoa(i.value)};
  var dec=byId('decryptBtn');if(dec)dec.onclick=function(){var i=byId('cryptoInput'),o=byId('cryptoOutput');if(!i||!o)return;try{o.textContent=atob(i.value)}catch(e){o.textContent='❌ 解码失败'}};
  var conv=byId('convertUnitBtn');if(conv)conv.onclick=function(){
    var v=byId('unitValue'),t=byId('unitType'),f=byId('unitFrom'),to=byId('unitTo'),o=byId('unitOutput');
    if(!v||!o)return;
    fetch('/api/tools/unit-convert',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({value:parseFloat(v.value)||0,fromUnit:f?f.value:'m',toUnit:to?to.value:'cm',type:t?t.value:'length'})}).then(function(r){return r.json()}).then(function(d){if(d.success)o.textContent=d.result||d.value;else o.textContent='❌ '+d.error}).catch(function(){o.textContent='❌ 请求失败'});
  };
  var picker=byId('colorPicker'),co=byId('colorOutput');
  if(picker&&co)picker.oninput=function(){var r=parseInt(picker.value.slice(1,3),16),g=parseInt(picker.value.slice(3,5),16),b=parseInt(picker.value.slice(5,7),16);co.innerHTML='HEX: '+picker.value+'<br>RGB: rgb('+r+','+g+','+b+')'};
  var ch=byId('copyHexBtn');if(ch)ch.onclick=function(){var p=byId('colorPicker');if(!p)return;navigator.clipboard.writeText(p.value).then(function(){toast('已复制')})};
  var cr=byId('copyRgbBtn');if(cr)cr.onclick=function(){var p=byId('colorPicker');if(!p)return;var h=p.value;navigator.clipboard.writeText('rgb('+parseInt(h.slice(1,3),16)+','+parseInt(h.slice(3,5),16)+','+parseInt(h.slice(5,7),16)+')').then(function(){toast('已复制')})};
  var rand=byId('randomColorBtn');if(rand)rand.onclick=function(){var p=byId('colorPicker'),o=byId('colorOutput');if(!p||!o)return;var c='#'+Math.floor(Math.random()*16777215).toString(16).padStart(6,'0');p.value=c;var r=parseInt(c.slice(1,3),16),g=parseInt(c.slice(3,5),16),b=parseInt(c.slice(5,7),16);o.innerHTML='HEX: '+c+'<br>RGB: rgb('+r+','+g+','+b+')'};
}
/* ===== 团 ===== */
function renderCommunity(){
  var el=byId('communityList');if(!el)return;
  fetch('/api/community/list').then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.communities||!d.communities.length){el.innerHTML='<div class="placeholder-box"><i class="fas fa-users"></i><p>暂无团，点击下方创建</p></div>';return}
    el.innerHTML=d.communities.map(function(c){
      return'<div class="community-card card"><div class="card-header"><div class="community-avatar"><i class="fas fa-users"></i></div><div><div class="community-name">'+esc(c.name)+'</div><div class="community-cat">'+esc(c.category||'其他')+'</div></div></div><div class="community-desc">'+esc(c.description||'')+'</div><div class="community-stats"><span><i class="fas fa-user"></i> '+(c.member_count||1)+'</span><span><i class="fas fa-clock"></i> '+esc(c.created_at||'')+'</span></div></div>';
    }).join('');
  }).catch(function(){});
}
function bindGroupTabs(){
  qsa('[data-gtab]').forEach(function(tab){
    tab.onclick=function(){
      qsa('[data-gtab]').forEach(function(t){t.classList.remove('active')});
      tab.classList.add('active');
      renderCommunity();
    };
  });
}

/* ===== 聊天 ===== */
function isWide(){return window.innerWidth>=768}

function initChat(){
  // 重置会话状态
  if(CHAT_POLL){clearInterval(CHAT_POLL);CHAT_POLL=null}
  CURRENT_CHAT_ID=null;
  // 初始布局：窄屏只显示好友列表，宽屏双栏
  var cv=byId('chatConvCol'),ia=byId('chatInputArea');
  if(cv){cv.classList.remove('active');cv.style.display=isWide()?'flex':'none'}
  if(ia)ia.style.display='none';
  var ti=byId('chatConvTitle');
  if(ti)ti.textContent='选择一个好友开始聊天';
  var ms=byId('chatMessages');
  if(ms)ms.innerHTML='<div class="chat-empty">选择一个好友开始聊天</div>';
  // 加载数据
  loadFriendList();
  loadRequests();
  loadJuniusHistory();
  // 聊天 tab 切换
  qsa('[data-ctab]').forEach(function(tab){
    tab.onclick=function(){
      qsa('[data-ctab]').forEach(function(t){t.classList.remove('active')});
      tab.classList.add('active');var ct=tab.getAttribute('data-ctab');
      qsa('.chat-list-scroll').forEach(function(s){s.style.display='none'});
      if(ct==='friends'){byId('friendList').style.display='';loadFriendList();}
      if(ct==='requests'){byId('requestList').style.display='';}
      if(ct==='junius'){byId('juniusHistory').style.display='';}
    };
  });
  // 返回按钮
  var bb=byId('chatBackBtn');if(bb)bb.onclick=backFromChat;
  // 窗口尺寸变化
  window.addEventListener('resize',onChatResize);
}
function onChatResize(){
  var cv=byId('chatConvCol'),bb=byId('chatBackBtn'),tit=byId('chatConvTitle'),ms=byId('chatMessages'),ia=byId('chatInputArea');if(!cv)return;
  if(isWide()){
    cv.classList.remove('active');
    cv.style.display=CURRENT_CHAT_ID?'flex':'none';
    if(bb)bb.style.display='none';
  } else {
    if(CURRENT_CHAT_ID){
      cv.style.display='flex';
      cv.classList.add('active');
      if(bb)bb.style.display='';
    } else {
      cv.style.display='none';
      cv.classList.remove('active');
      if(bb)bb.style.display='none';
      if(ia)ia.style.display='none';
      if(ms)ms.innerHTML='<div class="chat-empty">选择一个好友开始聊天</div>';
      if(tit)tit.textContent='选择一个好友开始聊天';
    }
  }
}
function backFromChat(){
  // 清除会话，回到好友列表初始状态
  if(CHAT_POLL){clearInterval(CHAT_POLL);CHAT_POLL=null}
  CURRENT_CHAT_ID=null;
  var cv=byId('chatConvCol'),bb=byId('chatBackBtn'),ia=byId('chatInputArea'),ms=byId('chatMessages'),ti=byId('chatConvTitle');
  if(cv){cv.classList.remove('active');cv.style.display=isWide()?'flex':'none'}
  if(bb)bb.style.display='none';
  if(ia)ia.style.display='none';
  if(ms)ms.innerHTML='<div class="chat-empty">选择一个好友开始聊天</div>';
  if(ti)ti.textContent='选择一个好友开始聊天';
  // 好友 tab 设为激活
  qsa('[data-ctab]').forEach(function(t){t.classList.remove('active')});
  var ft=document.querySelector('[data-ctab="friends"]');
  if(ft)ft.classList.add('active');
  qsa('.chat-list-scroll').forEach(function(s){s.style.display='none'});
  var fl=byId('friendList');if(fl)fl.style.display='';
}
function navigateToConv(){
  if(!isWide()){
    var cv=byId('chatConvCol'),bb=byId('chatBackBtn');
    if(cv){cv.style.display='flex';cv.classList.add('active')}
    if(bb)bb.style.display='';
  }
}

function loadFriendList(){
  var el=byId('friendList');if(!el)return;
  fetch('/api/friends/list?user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.friends||!d.friends.length){el.innerHTML='<div class="placeholder-box" style="padding:20px"><p>暂无好友</p></div>';return}
    el.innerHTML=d.friends.map(function(u){
      var name=esc(u.nickname||u.username);
      var onlineHtml=u.is_online?'<span class="online-dot"></span>':'';
      var badgeHtml=u.unread>0?'<span class="badge">'+u.unread+'</span>':'';
      return'<div class="chat-user-item" data-uid="'+u.id+'" data-name="'+name+'"><div class="avatar"><i class="fas fa-user"></i>'+onlineHtml+'</div><div style="flex:1;min-width:0"><div class="friend-name">'+name+'</div><div class="friend-username">@'+esc(u.username)+'</div></div>'+badgeHtml+'</div>';
    }).join('');
    el.querySelectorAll('.chat-user-item').forEach(function(item){
      item.onclick=function(){
        var uid=parseInt(item.getAttribute('data-uid'));
        var name=item.getAttribute('data-name');
        openChat(uid,name);
      };
    });
  }).catch(function(){});
}
function loadRequests(){
  var el=byId('requestList');if(!el)return;
  fetch('/api/friends/requests?user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.requests||!d.requests.length){el.innerHTML='<div class="placeholder-box" style="padding:20px"><p>暂无申请</p></div>';return}
    el.innerHTML=d.requests.map(function(r){
      return'<div style="padding:10px;border-bottom:1px solid rgba(0,0,0,0.04);display:flex;justify-content:space-between;align-items:center"><span>'+esc(r.username||'用户')+'</span><div><button class="btn btn-sm btn-accent" data-req="'+r.id+'" data-act="accept">同意</button><button class="btn btn-sm btn-danger" data-req="'+r.id+'" data-act="reject" style="margin-left:4px">拒绝</button></div></div>';
    }).join('');
    el.querySelectorAll('[data-req]').forEach(function(btn){
      btn.onclick=function(){
        fetch('/api/friends/handle',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:parseInt(this.getAttribute('data-req')),action:this.getAttribute('data-act')})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('操作成功');loadRequests()}else toast('操作失败')}).catch(function(){});
      };
    });
  }).catch(function(){});
}
function openChat(uid,name){
  if(CHAT_POLL){clearInterval(CHAT_POLL);CHAT_POLL=null}
  CURRENT_CHAT_ID=null;
  var ti=byId('chatConvTitle'),ia=byId('chatInputArea'),ms=byId('chatMessages');
  if(ti)ti.textContent='与 '+name+' 聊天中';
  if(ia)ia.style.display='';
  if(ms)ms.innerHTML='<div class="chat-empty"><i class="fas fa-spinner fa-spin"></i> 正在建立连接...</div>';
  navigateToConv();
  fetch('/api/chat/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:USER_ID,target_id:uid})}).then(function(r){return r.json()}).then(function(d){
    if(!d.success){if(ms)ms.innerHTML='<div class="chat-empty">创建会话失败</div>';return}
    CURRENT_CHAT_ID=d.chat_id;
    loadMessages();
    CHAT_POLL=setInterval(loadMessages,3000);
  }).catch(function(){if(ms)ms.innerHTML='<div class="chat-empty">请求失败</div>'});
}
function loadMessages(){
  if(!CURRENT_CHAT_ID)return;
  fetch('/api/chat/messages?chat_id='+CURRENT_CHAT_ID+'&user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.messages)return;
    var el=byId('chatMessages');if(!el)return;
    el.innerHTML=d.messages.map(function(m){
      var isMe=parseInt(m.sender_id)===USER_ID;
      return'<div class="chat-msg '+(isMe?'me':'other')+'"><div class="bubble">'+esc(m.content)+'</div><div class="time">'+esc(m.created_at||'')+'</div></div>';
    }).join('');
    el.scrollTop=el.scrollHeight;
  }).catch(function(){});
}
function sendMessage(){
  if(!CURRENT_CHAT_ID)return;
  var inp=byId('chatInput');if(!inp||!inp.value.trim())return;
  var content=inp.value.trim();inp.value='';
  fetch('/api/chat/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:CURRENT_CHAT_ID,sender_id:USER_ID,content:content})}).then(function(r){return r.json()}).then(function(d){
    if(d.success){loadMessages()}else toast('发送失败');
  }).catch(function(){toast('发送失败')});
}
function loadJuniusHistory(){
  var el=byId('juniusHistory');if(!el)return;
  fetch('/api/junius/history?user_id='+USER_ID).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.messages||!d.messages.length){el.innerHTML='<div class="placeholder-box" style="padding:20px"><p>暂无对话记录</p></div>';return}
    el.innerHTML='<div style="margin-bottom:8px;font-size:13px;color:var(--accent)">对话面板</div>'+
      d.messages.slice(-10).map(function(m){
        var who=m.is_user?'你':'Junius';
        return'<div style="padding:6px 0;border-bottom:1px solid rgba(0,0,0,0.03)"><strong>'+who+':</strong> '+esc(m.content)+' <span style="font-size:10px;color:var(--text-dim)">'+esc(m.created_at||'')+'</span></div>';
      }).join('');
  }).catch(function(){});
}

/* ===== 启动时绑定事件 ===== */
function bindEvents(){
byId('sendChatBtn').onclick=sendMessage;
var ci=byId('chatInput');if(ci)ci.onkeydown=function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}};
var cgb=byId('createGroupBtn');if(cgb)cgb.onclick=function(){var m=byId('createGroupModal');if(m)m.classList.add('active')};
var ccg=byId('cancelCreateGroup');if(ccg)ccg.onclick=function(){var m=byId('createGroupModal');if(m)m.classList.remove('active')};
var cgm=byId('createGroupModal');if(cgm)cgm.onclick=function(e){if(e.target===this)this.classList.remove('active')};
byId('submitCreateGroup').onclick=function(){
  var name=byId('createGroupName'),desc=byId('createGroupDesc'),cat=byId('createGroupCategory'),msg=byId('createGroupMsg');
  if(!name||!name.value.trim()){msg.textContent='请输入团名称';return}
  fetch('/api/community/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name.value.trim(),description:desc?desc.value:'',category:cat?cat.value:'其他'})}).then(function(r){return r.json()}).then(function(d){
    if(d.success){toast('创建成功！');byId('createGroupModal').classList.remove('active');name.value='';if(desc)desc.value='';if(msg)msg.textContent='';renderCommunity()}
    else{if(msg)msg.textContent=d.error||'创建失败'}
  }).catch(function(){if(msg)msg.textContent='请求失败'});
};
}

/* ===== 管理面板 ===== */
function renderAdmin(){
  var el=byId('adminContent');if(!el)return;
  if(ADMIN_TOKEN){renderAdminContent();return}
  el.innerHTML=
    '<div class="admin-lock"><i class="fas fa-lock" style="font-size:40px;color:var(--accent-dim)"></i><p style="margin:12px 0;color:var(--text-bright)">管理面板已锁定</p>'+
    '<input id="adminUnlockPwd" type="password" placeholder="输入密码解锁..." style="max-width:280px;margin:0 auto 8px">'+
    '<div id="adminUnlockMsg" style="font-size:12px;color:var(--danger);margin-bottom:8px"></div>'+
    '<button class="btn btn-accent" id="adminUnlockBtn">解锁</button></div>';
  byId('adminUnlockBtn').onclick=function(){
    var pwd=byId('adminUnlockPwd'),msg=byId('adminUnlockMsg');
    if(!pwd||!pwd.value.trim()){if(msg)msg.textContent='请输入密码';return}
    fetch('/api/verify_pwd.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pwd.value.trim()})}).then(function(r){return r.json()}).then(function(d){
      if(d.success&&d.token){ADMIN_TOKEN=d.token;sessionStorage.setItem('admin_token',d.token);renderAdminContent();toast('解锁成功')}
      else{if(msg)msg.textContent=d.error||'密码错误'}
    }).catch(function(){if(msg)msg.textContent='请求失败'});
  };
}
function renderAdminContent(){
  var el=byId('adminContent');if(!el||!ADMIN_TOKEN)return;
  el.innerHTML='<div class="placeholder-box"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';
  // 统计数据
  fetch('/api/admin/pending-users?token='+ADMIN_TOKEN).then(function(r){return r.json()}).then(function(d){
    var pending=d&&d.users?d.users.length:0;
    fetch('/api/admin/users?token='+ADMIN_TOKEN).then(function(r2){return r2.json()}).then(function(d2){
      var total=d2&&d2.users?d2.users.length:0;
      el.innerHTML=
        '<div class="admin-stat-grid"><div class="admin-stat-card"><div class="num">'+total+'</div><div class="label">总用户</div></div><div class="admin-stat-card"><div class="num">'+pending+'</div><div class="label">待审核</div></div></div>'+
        '<div class="chat-tabs"><button class="chat-tab active" data-asec="pending">待审核</button><button class="chat-tab" data-asec="users">用户管理</button></div>'+
        '<div id="adminSectionContent"></div>';
      bindAdminTabs();
      loadPendingUsers();
    }).catch(function(){});
  }).catch(function(){});
}
function bindAdminTabs(){
  qsa('[data-asec]').forEach(function(t){
    t.onclick=function(){
      qsa('[data-asec]').forEach(function(s){s.classList.remove('active')});
      t.classList.add('active');
      if(t.getAttribute('data-asec')==='pending')loadPendingUsers();
      else loadUserList();
    };
  });
}
function loadPendingUsers(){
  var el=byId('adminSectionContent');if(!el||!ADMIN_TOKEN)return;
  el.innerHTML='<div class="placeholder-box"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';
  fetch('/api/admin/pending-users?token='+ADMIN_TOKEN).then(function(r){return r.json()}).then(function(d){
    if(!d.success){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>';return}
    if(!d.users||!d.users.length){el.innerHTML='<div class="placeholder-box"><i class="fas fa-check-circle" style="color:var(--accent)"></i><p>暂无待审核用户</p></div>';return}
    el.innerHTML=d.users.map(function(u){
      return'<div class="card" style="display:flex;justify-content:space-between;align-items:center"><div><div style="color:var(--text-bright);font-weight:600">'+esc(u.username)+'</div><div style="color:var(--text-dim);font-size:12px">注册: '+esc(u.created_at||'')+'</div></div><div><button class="btn btn-sm btn-accent" data-aprv="'+u.id+'">通过</button><button class="btn btn-sm btn-danger" data-rej="'+u.id+'" style="margin-left:4px">拒绝</button></div></div>';
    }).join('');
    el.querySelectorAll('[data-aprv]').forEach(function(b){
      b.onclick=function(){fetch('/api/admin/approve-user/'+this.getAttribute('data-aprv'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:ADMIN_TOKEN})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已通过');loadPendingUsers()}else toast(d.error||'操作失败')}).catch(function(){})};
    });
    el.querySelectorAll('[data-rej]').forEach(function(b){
      b.onclick=function(){fetch('/api/admin/reject-user/'+this.getAttribute('data-rej'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:ADMIN_TOKEN})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已拒绝');loadPendingUsers()}else toast(d.error)})};
    });
  }).catch(function(){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>'});
}
function loadUserList(){
  var el=byId('adminSectionContent');if(!el||!ADMIN_TOKEN)return;
  fetch('/api/admin/users?token='+ADMIN_TOKEN).then(function(r){return r.json()}).then(function(d){
    if(!d.success||!d.users){el.innerHTML='<div class="placeholder-box"><p>加载失败</p></div>';return}
    el.innerHTML=d.users.map(function(u){
      return'<div class="card" style="display:flex;justify-content:space-between;align-items:center"><div><div style="color:var(--text-bright)">'+esc(u.username)+'</div><div style="color:var(--text-dim);font-size:12px">'+esc(u.role||'user')+' · '+(u.status||'')+'</div></div><button class="btn btn-sm btn-danger" data-del="'+u.id+'">删除</button></div>';
    }).join('');
    el.querySelectorAll('[data-del]').forEach(function(b){
      b.onclick=function(){
        if(!confirm('确定删除该用户？'))return;
        fetch('/api/admin/delete-user/'+this.getAttribute('data-del'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:ADMIN_TOKEN})}).then(function(r){return r.json()}).then(function(d){if(d.success){toast('已删除');loadUserList()}else toast(d.error||'操作失败')}).catch(function(){});
      };
    });
  }).catch(function(){});
}

/* ===== 关闭按钮 ===== */
qsa('[data-close]').forEach(function(btn){
  btn.onclick=function(){togglePanel(this.getAttribute('data-close'))};
});

/* ===== 应用启动 ===== */
function startApp(){
  initSidebar();
  bindEvents();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startApp);
else startApp();
