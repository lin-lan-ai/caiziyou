<?php
require_once __DIR__ . '/../includes/community_config.php';
if (!isCommunityLoggedIn()) { communityRedirect('login.php'); }
$user = getCurrentCommunityUser();
$userId = getCurrentCommunityUserId();
$userRole = $user['role'] ?? 'user';
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.5">
<meta http-equiv="Cache-Control" content="no-cache,no-store,must-revalidate">
<title>菜籽游 · 极客社交</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#f5f5f7;--bg2:#ffffff;--bg3:#eeedf0;--surface:rgba(255,255,255,0.7);--surface2:#e8e8ed;--accent:#007aff;--accent-dim:rgba(0,122,255,0.12);--text:#1c1c1e;--text-dim:#8e8e93;--text-bright:#000;--danger:#ff3b30;--sidebar-w:120px;--radius:10px;--radius-lg:16px;--font:-apple-system,BlinkMacSystemFont,'SF Pro','Helvetica Neue',system-ui,sans-serif;--shadow:0 2px 12px rgba(0,0,0,0.06);--shadow-lg:0 8px 30px rgba(0,0,0,0.1)}
html,body{height:100%;background:var(--bg);color:var(--text);font:15px/1.6 var(--font);overflow:hidden;-webkit-font-smoothing:antialiased}
a{color:var(--accent);text-decoration:none}
::-webkit-scrollbar{width:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--surface2);border-radius:3px}
#app{display:flex;height:100vh;width:100vw}
.sidebar{width:var(--sidebar-w);flex-shrink:0;background:rgba(255,255,255,0.72);-webkit-backdrop-filter:blur(20px) saturate(180%);backdrop-filter:blur(20px) saturate(180%);display:flex;flex-direction:column;border-right:1px solid rgba(0,0,0,0.06);padding:12px 0;z-index:20;overflow-y:auto}
.sidebar-item{display:flex;flex-direction:column;align-items:center;gap:4px;padding:12px 8px;cursor:pointer;transition:.2s;color:var(--text-dim);border-left:3px solid transparent;font-size:11px;border-radius:6px;margin:2px 6px}
.sidebar-item i{font-size:20px;transition:.2s}
.sidebar-item:hover{color:var(--text);background:rgba(0,0,0,0.04)}
.sidebar-item.active,.sidebar-item.active i{color:var(--accent);border-left-color:var(--accent);background:var(--accent-dim)}
.sidebar-item span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:80px}
.content-area{flex:1;position:relative;overflow:hidden;background:var(--bg)}
.panel-default{position:absolute;inset:32px;display:flex;align-items:center;justify-content:center;z-index:0;text-align:center}
.panel-default i{font-size:52px;color:var(--accent);margin-bottom:16px}
.panel-default p{font-size:18px;color:var(--text-bright)}
.panel-default small{font-size:13px;color:var(--text-dim);margin-top:8px}
.float-panel{position:absolute;inset:0;background:var(--bg);display:none;flex-direction:column;overflow:hidden;z-index:10;animation:panelIn .2s cubic-bezier(.25,.1,.25,1)}
.float-panel.active{display:flex!important}
@keyframes panelIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.panel-bar{display:flex;align-items:center;gap:12px;padding:14px 24px;background:rgba(255,255,255,0.65);-webkit-backdrop-filter:blur(20px);backdrop-filter:blur(20px);border-bottom:1px solid rgba(0,0,0,0.06);flex-shrink:0;font-weight:600;font-size:16px;color:var(--text-bright);z-index:2}
.panel-bar.admin-panel{padding-left:88px}
.panel-bar span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.panel-bar-close{background:rgba(0,0,0,0.06);border:none;color:var(--text-dim);font-size:20px;cursor:pointer;transition:.2s;line-height:1;padding:2px 10px;border-radius:20px;flex-shrink:0}
.panel-bar-close:hover{background:rgba(0,0,0,0.12);color:var(--danger)}
.panel-scroll{flex:1;overflow-y:auto;padding:24px}
.card{background:var(--surface);border:1px solid rgba(0,0,0,0.04);border-radius:var(--radius-lg);padding:16px;margin-bottom:12px;transition:.2s;box-shadow:var(--shadow)}
.card:hover{border-color:var(--accent);box-shadow:var(--shadow-lg)}
.placeholder-box{text-align:center;padding:60px 20px;color:var(--text-dim)}
.placeholder-box i{font-size:40px;margin-bottom:12px;color:var(--accent-dim)}

.tool-output{background:rgba(0,0,0,0.03);border-radius:var(--radius);padding:8px 12px;font-size:13px;color:var(--accent);font-family:monospace;word-break:break-all;margin-top:6px}
.proxy-card{background:var(--surface);border:1px solid rgba(0,0,0,0.04);border-radius:var(--radius-lg);padding:16px;margin-bottom:10px;box-shadow:var(--shadow)}
.proxy-card h4{color:var(--accent);margin-bottom:8px}
.proxy-card p{font-size:13px;color:var(--text-dim)}
.community-avatar{width:40px;height:40px;border-radius:50%;background:var(--accent-dim);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.community-name{font-weight:600;color:var(--text-bright)}
.community-cat{font-size:11px;color:var(--text-dim)}
.community-desc{font-size:13px;color:var(--text);margin:4px 0}
.community-stats{display:flex;gap:16px;font-size:12px;color:var(--text-dim);margin-top:6px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border:none;border-radius:var(--radius);cursor:pointer;font-size:14px;font-weight:500;transition:.2s;background:rgba(0,0,0,0.07);color:var(--text)}
.btn:hover{background:rgba(0,0,0,0.12)}
.btn-accent{background:var(--accent);color:#fff}
.btn-accent:hover{background:#0062cc}
.btn-danger{background:var(--danger);color:#fff}
.btn-sm{padding:5px 14px;font-size:13px}
input,textarea,select{background:rgba(0,0,0,0.03);border:1px solid rgba(0,0,0,0.1);border-radius:var(--radius);color:var(--text);padding:10px 14px;font-size:14px;width:100%;outline:none;transition:border-color .2s;font-family:var(--font)}
input:focus,textarea:focus,select:focus{border-color:var(--accent)}
textarea{resize:vertical;min-height:60px}
.form-group{margin-bottom:12px}
.form-group label{display:block;font-size:12px;color:var(--text-dim);margin-bottom:4px}
.form-row{display:flex;gap:8px}
.form-row>*{flex:1}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:9999;display:none;align-items:center;justify-content:center;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px)}
.modal-overlay.active{display:flex}
.modal-box{background:rgba(255,255,255,0.85);-webkit-backdrop-filter:blur(40px);backdrop-filter:blur(40px);border-radius:var(--radius-lg);padding:24px;width:420px;max-width:90vw;max-height:80vh;overflow-y:auto;border:1px solid rgba(0,0,0,0.06);box-shadow:var(--shadow-lg)}
.modal-box h3{margin-bottom:16px;color:var(--text-bright)}
.community-card .card-header{display:flex;align-items:center;gap:12px;margin-bottom:8px}
.community-avatar{width:40px;height:40px;border-radius:50%;background:var(--accent-dim);display:flex;align-items:center;justify-content:center;flex-shrink:0}
.community-name{font-weight:600;color:var(--text-bright)}
.community-cat{font-size:11px;color:var(--text-dim)}
.community-desc{font-size:13px;color:var(--text);margin:4px 0}
.community-stats{display:flex;gap:16px;font-size:12px;color:var(--text-dim);margin-top:6px}
.chat-app{display:flex;height:100%}
.chat-list-col{width:30%;min-width:200px;flex-shrink:0;border-right:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;background:var(--bg2)}
.chat-list-tabs{display:flex;border-bottom:1px solid rgba(0,0,0,0.06)}
.chat-list-tab{flex:1;padding:10px;text-align:center;cursor:pointer;font-size:13px;color:var(--text-dim);transition:.2s;background:none;border:none}
.chat-list-tab.active{color:var(--accent);border-bottom:2px solid var(--accent)}
.chat-list-scroll{flex:1;overflow-y:auto}
.chat-user-item{padding:12px 14px;cursor:pointer;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(0,0,0,0.04);transition:.2s}
.chat-user-item:hover{background:var(--accent-dim)}
.chat-user-item .avatar{width:40px;height:40px;border-radius:50%;background:var(--accent-dim);display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative}
.chat-user-item .online-dot{width:10px;height:10px;border-radius:50%;background:#34c759;border:2px solid var(--bg2);position:absolute;bottom:-2px;right:-2px}
.chat-user-item .badge{min-width:18px;height:18px;border-radius:9px;background:var(--danger);color:#fff;font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;padding:0 5px;margin-left:auto}
.chat-conv-col{flex:1;display:flex;flex-direction:column;min-width:0}
.chat-conv-header{display:flex;align-items:center;gap:8px;padding:14px 20px;border-bottom:1px solid rgba(0,0,0,0.06);font-weight:600;color:var(--text-bright);font-size:15px}
.chat-back-btn{background:none;border:none;color:var(--accent);font-size:18px;cursor:pointer;padding:0 4px}
.chat-messages{flex:1;overflow-y:auto;padding:16px 20px}
.chat-empty{text-align:center;padding:40px;color:var(--text-dim);font-size:14px}
.chat-msg{margin-bottom:14px}
.chat-msg .bubble{display:inline-block;padding:10px 16px;border-radius:18px;max-width:70%;font-size:15px;line-height:1.45}
.chat-msg.me{text-align:right}
.chat-msg.me .bubble{background:var(--accent);color:#fff}
.chat-msg.other .bubble{background:#e8e8ed;color:var(--text)}
.chat-msg .time{font-size:11px;color:var(--text-dim);margin-top:3px}
.chat-input-area{display:flex;gap:8px;padding:12px 16px;border-top:1px solid rgba(0,0,0,0.06)}
.chat-input-area textarea{flex:1;min-height:38px;max-height:80px}
.chat-input-area button{flex-shrink:0}
.tool-section{margin-bottom:28px}
.tool-section-title{font-size:16px;color:var(--accent);margin-bottom:14px;display:flex;align-items:center;gap:8px;font-weight:600}
.tool-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px}
.tool-card{background:var(--surface);border:1px solid rgba(0,0,0,0.04);border-radius:var(--radius-lg);padding:18px;box-shadow:var(--shadow)}
.tool-card-title{font-size:14px;font-weight:600;color:var(--text-bright);margin-bottom:10px;display:flex;align-items:center;gap:6px}
.tool-card input,.tool-card textarea,.tool-card select{margin-bottom:8px}
.tool-buttons{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}
.feed-item{background:var(--surface);border-radius:var(--radius-lg);padding:16px 18px;margin-bottom:10px;border:1px solid rgba(0,0,0,0.04);box-shadow:var(--shadow)}
.feed-user{font-weight:600;color:var(--text-bright);margin-bottom:4px;font-size:14px}
.feed-content{font-size:14px;color:var(--text);margin-bottom:6px}
.feed-time{font-size:12px;color:var(--text-dim)}
.admin-lock{text-align:center;padding:50px 20px}
.admin-lock input{max-width:280px;margin:14px auto}
.admin-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:14px;margin-bottom:20px}
.admin-stat-card{background:var(--surface);border:1px solid rgba(0,0,0,0.04);border-radius:var(--radius-lg);padding:20px;text-align:center;box-shadow:var(--shadow)}
.admin-stat-card .num{font-size:32px;font-weight:700;color:var(--accent)}
.admin-stat-card .label{font-size:13px;color:var(--text-dim);margin-top:4px}
@media(max-width:768px){:root{--sidebar-w:72px}.sidebar-item{padding:10px 4px;font-size:10px}.sidebar-item i{font-size:18px}.sidebar-item span{max-width:60px}.tool-grid{grid-template-columns:1fr}.admin-stat-grid{grid-template-columns:repeat(2,1fr)}
.chat-app{position:relative}
.chat-list-col{width:100%!important;min-width:0!important;border-right:none!important}
.chat-conv-col{position:absolute;inset:0;z-index:5;background:var(--bg);display:none}
.chat-conv-col.active{display:flex}}
@media(max-width:480px){:root{--sidebar-w:60px}.sidebar-item{padding:8px 2px}.sidebar-item i{font-size:16px}.sidebar-item span{display:none}.panel-scroll{padding:12px}}
.friend-name{color:var(--text-bright);font-size:14px}
.friend-username{color:var(--text-dim);font-size:12px}
</style>
<script>USER_ID=<?=$userId?>;USER_ROLE='<?=$userRole?>'</script>
<script src="/assets/js/app.js?v=20260501v2"></script>
</head>
<body>
<div id="app">
  <div class="sidebar" id="sidebar">
    <div class="sidebar-item active" data-tab="discover"><i class="fas fa-compass"></i><span>发现</span></div>
    <div class="sidebar-item" data-tab="service"><i class="fas fa-concierge-bell"></i><span>服务</span></div>
    <div class="sidebar-item" data-tab="group"><i class="fas fa-users"></i><span>团</span></div>
    <div class="sidebar-item" data-tab="chat"><i class="fas fa-comment-dots"></i><span>消息</span></div>
    <div class="sidebar-item admin-only" data-tab="admin"><i class="fas fa-shield-alt"></i><span>管理</span></div>
  </div>
  <div class="content-area">
    <div class="panel-default" id="panelDefault">
      <div><i class="fas fa-compass"></i><p>欢迎来到菜籽游</p><small>点击左侧菜单探索各项功能</small></div>
    </div>
    <div class="float-panel" id="panel-discover">
      <div class="panel-bar"><span><i class="fas fa-compass"></i> 发现 · 团推流</span><button class="panel-bar-close" data-close="discover">&times;</button></div>
      <div class="panel-scroll" id="feedList"></div>
    </div>
    <div class="float-panel" id="panel-service">
      <div class="panel-bar"><span><i class="fas fa-concierge-bell"></i> 公共服务</span><button class="panel-bar-close" data-close="service">&times;</button></div>
      <div class="panel-scroll" id="serviceContent"></div>
    </div>
    <div class="float-panel" id="panel-group">
      <div class="panel-bar"><span><i class="fas fa-users"></i> 团 · 聚合</span><button class="panel-bar-close" data-close="group">&times;</button></div>
      <div class="panel-scroll">
        <div class="chat-tabs" id="groupTabs">
          <button class="chat-tab active" data-gtab="square">团广场</button>
          <button class="chat-tab" data-gtab="my">我的团</button>
        </div>
        <div id="communityList" style="margin-top:12px"></div>
        <div style="text-align:right;margin-top:12px"><button class="btn btn-accent" id="createGroupBtn"><i class="fas fa-plus"></i> 创建团</button></div>
      </div>
    </div>
    <div class="float-panel" id="panel-chat">
      <div class="panel-bar"><span><i class="fas fa-comment-dots"></i> 消息</span><button class="panel-bar-close" data-close="chat">&times;</button></div>
      <div class="chat-app" id="chatApp">
        <div class="chat-list-col" id="chatListCol">
          <div class="chat-list-tabs">
            <button class="chat-list-tab active" data-ctab="friends">好友</button>
            <button class="chat-list-tab" data-ctab="requests">申请</button>
            <button class="chat-list-tab" data-ctab="junius">Junius</button>
          </div>
          <div class="chat-list-scroll" id="friendList"></div>
          <div class="chat-list-scroll" id="requestList" style="display:none"></div>
          <div class="chat-list-scroll" id="juniusHistory" style="display:none;padding:12px;font-size:13px"></div>
        </div>
        <div class="chat-conv-col" id="chatConvCol">
          <div class="chat-conv-header" id="chatConvHeader">
            <button class="chat-back-btn" id="chatBackBtn" style="display:none"><i class="fas fa-arrow-left"></i></button>
            <span id="chatConvTitle">选择一个好友开始聊天</span>
          </div>
          <div class="chat-messages" id="chatMessages">
            <div class="chat-empty">选择一个好友开始聊天</div>
          </div>
          <div class="chat-input-area" id="chatInputArea" style="display:none">
            <textarea id="chatInput" placeholder="输入消息..." rows="1"></textarea>
            <button class="btn btn-accent" id="sendChatBtn"><i class="fas fa-paper-plane"></i></button>
          </div>
        </div>
      </div>
      </div>
    </div>
    <div class="float-panel" id="panel-admin">
      <div class="panel-bar admin-panel"><span><i class="fas fa-shield-alt"></i> 管理面板</span><button class="panel-bar-close" data-close="admin">&times;</button></div>
      <div class="panel-scroll" id="adminContent"></div>
    </div>
  </div>
</div>
<div class="modal-overlay" id="createGroupModal">
  <div class="modal-box">
    <h3><i class="fas fa-plus-circle" style="color:var(--accent)"></i> 创建团</h3>
    <div class="form-group"><label>团名称</label><input id="createGroupName" placeholder="输入团名称"></div>
    <div class="form-group"><label>简介</label><textarea id="createGroupDesc" placeholder="介绍一下你的团..." rows="3"></textarea></div>
    <div class="form-group"><label>分类</label><select id="createGroupCategory"><option value="游戏">游戏</option><option value="技术">技术</option><option value="生活">生活</option><option value="其他">其他</option></select></div>
    <div id="createGroupMsg" style="font-size:12px;color:var(--danger);margin-bottom:8px"></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn" id="cancelCreateGroup">取消</button>
      <button class="btn btn-accent" id="submitCreateGroup">创建</button>
    </div>
  </div>
</div>
</body>
</html>
